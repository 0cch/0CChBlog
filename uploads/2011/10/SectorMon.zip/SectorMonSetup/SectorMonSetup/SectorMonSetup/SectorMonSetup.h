#ifndef __SECTOR_MON_SETUP_H__
#define __SECTOR_MON_SETUP_H__

#include "windows.h"

#define BITMAP_TARGET_DISK			"C:\\"
#define BITMAP_SAVE_PATHNAME		"D:\\Bitmap.dat"
#define VOLUME_FILTER_PATH			"SYSTEM\\CurrentControlSet\\Control\\Class\\{71A27CDD-812A-11D0-BEC7-08002BE2092F}"
#define SECMON_CONFIG_PATH			"SYSTEM\\CurrentControlSet\\Control\\SecMon"
#define SECMON_CONFIG_CONTROL		"Current"
#define VOLUME_FILTER_VALUE			"UpperFilters"
#define WINDOWS_ROOT				"systemroot"
#define DRIVER_PATH					"\\system32\\drivers\\"
#define DRIVER_BIN_PATH				"SectorMon.sys"
#define DRIVER_NAME					"SectorMon"
#define SNAPFILE_SAVE_PATHNAME		"D:\\SpareFile.dat"
#define PAGEFILE_VOLUME				'D'
#define PAGEFILE_REG_PATH			"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management"
#define PAGEFILE_REG_VAL			"PagingFiles"

#include <stdio.h>
#include <vector>
#include <string>

using namespace std;

typedef vector<string> CStringVector;

BOOL InstallDriver( IN SC_HANDLE SchSCManager, IN LPCTSTR DriverName, IN LPCTSTR ServiceExe, ULONG StartType);
BOOL RemoveDriver( IN SC_HANDLE SchSCManager, IN LPCTSTR DriverName );
VOID AppendStringVector(CStringVector &StringVector, PCHAR String);
BOOL HasStringVector(CStringVector &StringVector, PCHAR String);
BOOL RemoveStringVector(CStringVector &StringVector, PCHAR String);
PCHAR MakeMultiSZ(CStringVector &StringVector, ULONG *BufSize);
VOID FreeMultiSZ(PCHAR Buf);
ULONG ParseMultiSZ(CStringVector &StringVector, PCHAR Buffer, ULONG Size);
BOOL GetFilterDrivers(PCHAR Buffer, ULONG Size);
BOOL SetFilterDrivers(PCHAR Buffer, ULONG Size);
BOOL RegisterBootDriver(PCHAR DriverName, PCHAR Path);
BOOL UnregisterBootDriver(PCHAR DriverName);
ULONG GetDriverRoot(PCHAR Buffer, ULONG Size);
BOOL AddUpperFilter(PCHAR DriverName);
BOOL RemoveUpperFilter(PCHAR DriverName);
BOOL CopyDriver(PCHAR DriverPath, ULONG Size);
BOOL UninstallSectorMon();
BOOL InstallSectorMon();
VOID DeleteBitmapAndSnap(PCHAR Bitmap, PCHAR SparseFile);
BOOL GenBitmapFile(PCHAR FileName);
VOID PrintUsage();
BOOL AddControlReg();
BOOL RemoveControlReg();
BOOL SetControlStatus(LONG Status);
LONG GetControlStatus();
BOOL ChangePageFilePath(CHAR NewVol);
#endif