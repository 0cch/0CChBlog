// SectorMonSetup.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "SectorMonSetup.h"


VOID AppendStringVector(CStringVector &StringVector, PCHAR String)
{
	StringVector.push_back(String);
}

BOOL HasStringVector(CStringVector &StringVector, PCHAR String)
{
	CStringVector::iterator it;
	BOOL Ret = FALSE;

	for (it = StringVector.begin(); it != StringVector.end(); it++) {

		if (*it == String) {
			Ret = TRUE;
			break;
		}
	}

	return Ret;
}

BOOL RemoveStringVector(CStringVector &StringVector, PCHAR String)
{
	CStringVector::iterator it;
	BOOL Ret = FALSE;

	for (it = StringVector.begin(); it != StringVector.end(); ) {

		if (*it == String) {
			it = StringVector.erase(it);
			Ret = TRUE;
			break;
		}
		else {
			it++;
		}
	}

	return Ret;
}

PCHAR MakeMultiSZ(CStringVector &StringVector, ULONG *BufSize)
{
	ULONG BufferSize = 0;
	PCHAR Buffer = NULL;
	ULONG i = 0;
	CStringVector::iterator it;


	for (it = StringVector.begin(); it != StringVector.end(); it++) {

		BufferSize += (*it).length() + 1;
	}

	BufferSize++;

	Buffer = new CHAR[BufferSize];
	ZeroMemory(Buffer, BufferSize);


	for (it = StringVector.begin(); it != StringVector.end(); it++) {

		memcpy(&Buffer[i], (*it).c_str(), (*it).length());
		i += (*it).length() + 1;
	}

	*BufSize = BufferSize;
	
	return Buffer;
}

VOID FreeMultiSZ(PCHAR Buf)
{
	delete[] Buf;
}


ULONG ParseMultiSZ(CStringVector &StringVector, PCHAR Buffer, ULONG Size)
{
	ULONG i = 0;
	ULONG Count = 0;

	while (Buffer[i] != 0) {

		StringVector.push_back(&Buffer[i]);
		i += strlen(&Buffer[i]) + 1;
		Count++;
	}

	return Count;
}


BOOL GetFilterDrivers(PCHAR Buffer, ULONG Size)
{
	HKEY hKey;
	ULONG BufLen = Size;
	LONG Ret;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		VOLUME_FILTER_PATH,
		0,
		KEY_QUERY_VALUE,
		&hKey) != ERROR_SUCCESS) {

		return FALSE;
	}

	Ret = RegQueryValueEx(hKey,
		VOLUME_FILTER_VALUE,
		NULL,
		NULL,
		(LPBYTE)Buffer,
		&BufLen);

	RegCloseKey(hKey);

	if (Ret != ERROR_SUCCESS) {
		return FALSE;
	}

	return TRUE;
}

BOOL SetFilterDrivers(PCHAR Buffer, ULONG Size)
{
	HKEY hKey;
	ULONG BufLen = Size;
	LONG Ret;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		VOLUME_FILTER_PATH,
		0,
		KEY_ALL_ACCESS,
		&hKey) != ERROR_SUCCESS) {

		return FALSE;
	}

	Ret = RegSetValueEx(hKey,
		VOLUME_FILTER_VALUE,
		NULL,
		REG_MULTI_SZ,
		(LPBYTE)Buffer,
		BufLen);

	RegCloseKey(hKey);

	if (Ret != ERROR_SUCCESS) {
		return FALSE;
	}

	return TRUE;
}


BOOL ChangePageFilePath(CHAR NewVol)
{
	HKEY hKey;
	CHAR Buffer[1024];
	ULONG BufLen = 1024;
	LONG Ret;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		PAGEFILE_REG_PATH,
		0,
		KEY_ALL_ACCESS,
		&hKey) != ERROR_SUCCESS) {

		return FALSE;
	}

	Ret = RegQueryValueEx(hKey,
		PAGEFILE_REG_VAL,
		NULL,
		NULL,
		(LPBYTE)Buffer,
		&BufLen);

	if (Ret != ERROR_SUCCESS) {

		RegCloseKey(hKey);
		return FALSE;
	}

	if (Buffer[0] != 'C' &&  Buffer[0] != 'c') {

		RegCloseKey(hKey);
		return TRUE;
	}

	Buffer[0] = NewVol;

	Ret = RegSetValueEx(hKey,
		PAGEFILE_REG_VAL,
		NULL,
		REG_MULTI_SZ,
		(LPBYTE)Buffer,
		BufLen);

	RegCloseKey(hKey);

	if (Ret != ERROR_SUCCESS) {
		return FALSE;
	}

	return TRUE;
}


BOOL RegisterBootDriver(PCHAR DriverName, PCHAR Path)
{
	SC_HANDLE schSCManager;
	BOOL Ret;

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (schSCManager == NULL) {

		return FALSE;
	}

	Ret = InstallDriver(schSCManager, DriverName, Path, SERVICE_BOOT_START);

	CloseServiceHandle(schSCManager);
	
	return Ret;
}

BOOL UnregisterBootDriver(PCHAR DriverName)
{
	SC_HANDLE schSCManager;
	BOOL Ret;

	schSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (schSCManager == NULL) {

		return FALSE;
	}

	Ret = RemoveDriver(schSCManager, DriverName);

	CloseServiceHandle(schSCManager);

	return Ret;
}


BOOL GenBitmapFile(PCHAR FileName)
{
	ULARGE_INTEGER TotalNumberOfBytes;
	BOOL Ret;
	ULONG BytePerSector;
	HANDLE BitmapFile;
	ULONG BitmapFileSize;

	Ret = GetDiskFreeSpaceEx(BITMAP_TARGET_DISK, 
		NULL, 
		&TotalNumberOfBytes, 
		NULL);

	if (!Ret) {

		return FALSE;
	}

	Ret = GetDiskFreeSpace(BITMAP_TARGET_DISK, 
		NULL, 
		&BytePerSector, 
		NULL,
		NULL);

	if (!Ret) {

		return FALSE;
	}

	BitmapFileSize = (ULONG)(TotalNumberOfBytes.QuadPart / (BytePerSector * 8));

	BitmapFile = CreateFile(FileName, 
		GENERIC_WRITE | GENERIC_READ, 
		0, 
		NULL, 
		CREATE_NEW, 
		FILE_ATTRIBUTE_NORMAL, 
		0);

	if (BitmapFile == INVALID_HANDLE_VALUE) {

		return FALSE;
	}

	SetFilePointer(BitmapFile, BitmapFileSize, NULL, FILE_BEGIN);
	SetEndOfFile(BitmapFile);

	CloseHandle(BitmapFile);

	return TRUE;
}

ULONG GetDriverRoot(PCHAR Buffer, ULONG Size)
{
	ULONG Ret = GetEnvironmentVariable(WINDOWS_ROOT, Buffer, Size);
	strcat_s(Buffer, Size, DRIVER_PATH);

	return Ret;
}


BOOL AddUpperFilter(PCHAR DriverName)
{
	BOOL Ret;
	CHAR FiltersName[1024];
	CStringVector StringVector;
	ULONG BufSize;
	PCHAR Buffer;

	Ret = GetFilterDrivers(FiltersName, 1024);
	if (!Ret) {

		return FALSE;
	}

	Ret = ParseMultiSZ(StringVector, FiltersName, 1024);
	if (!Ret) {

		return FALSE;
	}

	Ret = HasStringVector(StringVector, DriverName);
	if (Ret) {

		return TRUE;
	}

	AppendStringVector(StringVector, DriverName);

	Buffer = MakeMultiSZ(StringVector, &BufSize);

	Ret = SetFilterDrivers(Buffer, BufSize);

	FreeMultiSZ(Buffer);

	return Ret;

}

BOOL RemoveUpperFilter(PCHAR DriverName)
{
	BOOL Ret;
	CHAR FiltersName[1024];
	CStringVector StringVector;
	ULONG BufSize;
	PCHAR Buffer;

	Ret = GetFilterDrivers(FiltersName, 1024);
	if (!Ret) {

		return FALSE;
	}

	Ret = ParseMultiSZ(StringVector, FiltersName, 1024);
	if (!Ret) {

		return FALSE;
	}

	RemoveStringVector(StringVector, DriverName);
	

	Buffer = MakeMultiSZ(StringVector, &BufSize);

	Ret = SetFilterDrivers(Buffer, BufSize);

	FreeMultiSZ(Buffer);

	return Ret;
}


BOOL CopyDriver(PCHAR DriverPath, ULONG Size)
{
	CHAR DriverBinPath[MAX_PATH];
	PCHAR Pos;

	GetModuleFileName(NULL, DriverBinPath, MAX_PATH);

	Pos = strrchr(DriverBinPath, '\\');
	Pos++;
	*Pos = 0;

	strcat_s(DriverBinPath, MAX_PATH, DRIVER_BIN_PATH);

	GetDriverRoot(DriverPath, Size);

	strcat_s(DriverPath, Size, DRIVER_BIN_PATH);

	return CopyFile(DriverBinPath, DriverPath, FALSE);
}

BOOL AddControlReg()
{
	HKEY Key;
	LONG Ret;
	ULONG Status = 0;

	Ret = RegCreateKeyEx(HKEY_LOCAL_MACHINE, 
		SECMON_CONFIG_PATH, 
		NULL,
		NULL,
		0,
		KEY_ALL_ACCESS, 
		NULL, 
		&Key,
		NULL);

	if (Ret != ERROR_SUCCESS) {

		return FALSE;
	}


	Ret = RegSetValueEx(Key,
		SECMON_CONFIG_CONTROL,
		NULL,
		REG_DWORD,
		(LPBYTE)Status,
		sizeof(Status));

	RegCloseKey(Key);

	if (Ret != ERROR_SUCCESS) {

		return FALSE;
	}
	
	return TRUE;
}

BOOL RemoveControlReg()
{
	LONG Ret;

	Ret = RegDeleteKey(HKEY_LOCAL_MACHINE, SECMON_CONFIG_PATH);

	if (Ret != ERROR_SUCCESS) {

		return FALSE;
	}

	return TRUE;
}

BOOL SetControlStatus(LONG Status)
{
	HKEY hKey;
	LONG CurStatus = Status;
	BOOL Ret;
	ULONG BufLen = sizeof(ULONG);

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		SECMON_CONFIG_PATH,
		0,
		KEY_ALL_ACCESS,
		&hKey) != ERROR_SUCCESS) {

		return FALSE;
	}

	Ret = RegSetValueEx(hKey,
		SECMON_CONFIG_CONTROL,
		NULL,
		REG_DWORD,
		(LPBYTE)&CurStatus,
		BufLen);

	RegCloseKey(hKey);

	if (Ret != ERROR_SUCCESS) {
		return FALSE;
	}

	return TRUE;
}

LONG GetControlStatus()
{
	HKEY hKey;
	BOOL Ret;
	LONG Status;
	ULONG BufLen = sizeof(ULONG);

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		SECMON_CONFIG_PATH,
		0,
		KEY_QUERY_VALUE,
		&hKey) != ERROR_SUCCESS) {

			return -1;
	}

	Ret = RegQueryValueEx(hKey,
		SECMON_CONFIG_CONTROL,
		NULL,
		NULL,
		(LPBYTE)&Status,
		&BufLen);

	RegCloseKey(hKey);

	if (Ret != ERROR_SUCCESS) {
		return -1;
	}

	return Status;
}


BOOL UninstallSectorMon()
{
	BOOL Ret;
	CHAR DriverPath[MAX_PATH];
	GetDriverRoot(DriverPath, MAX_PATH);
	strcat_s(DriverPath, MAX_PATH, DRIVER_BIN_PATH);

	Ret = UnregisterBootDriver(DRIVER_NAME);
	if (!Ret) {

		return FALSE;
	}

	Ret = RemoveUpperFilter(DRIVER_NAME);
	if (!Ret) {

		return FALSE;
	}

	RemoveControlReg();

	DeleteFile(DriverPath);

	DeleteBitmapAndSnap(BITMAP_SAVE_PATHNAME, SNAPFILE_SAVE_PATHNAME);

	return TRUE;
}

BOOL InstallSectorMon()
{
	CHAR DriverPath[MAX_PATH];
	BOOL Ret;

	Ret = ChangePageFilePath(PAGEFILE_VOLUME);
	if (!Ret) {

		printf("ChangePageFilePath ERROR.\n");
		return FALSE;
	}


	Ret = GenBitmapFile(BITMAP_SAVE_PATHNAME);
	if (!Ret) {

		printf("GenBitmapFile ERROR.\n");
		return FALSE;
	}

	Ret = CopyDriver(DriverPath, MAX_PATH);
	if (!Ret) {

		printf("CopyDriver ERROR.\n");
		return FALSE;
	}

	Ret = RegisterBootDriver(DRIVER_NAME, DriverPath);
	if (!Ret) {

		printf("RegisterBootDriver ERROR.\n");
		return FALSE;
	}

	Ret = AddUpperFilter(DRIVER_NAME);
	if (!Ret) {

		printf("AddUpperFilter ERROR.\n");
		return FALSE;
	}

	AddControlReg();

	return TRUE;
}

VOID DeleteBitmapAndSnap(PCHAR Bitmap, PCHAR SparseFile)
{
	MoveFileEx(Bitmap, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
	MoveFileEx(SparseFile, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);
}

VOID PrintUsage()
{
	printf("SectorMonSetup [-inst][-uninst][-res] \n");
}

int _tmain(int argc, _TCHAR* argv[])
{
	if (argc != 2) {

		PrintUsage();
		return 1;
	}

	if (_stricmp(argv[1], "-inst") == 0) {

		if (!InstallSectorMon()) {

			printf("Install SectorMon failed!\n");
			return 1;
		}
		
		printf("Install SectorMon success!\n");
	}
	else if (_stricmp(argv[1], "-uninst") == 0) {

		if (!UninstallSectorMon()) {

			printf("Uninstall SectorMon failed!\n");
			return 1;
		}

		printf("Uninstall SectorMon success!\n");
	}
	else if (_stricmp(argv[1], "-res") == 0) {

		if (!SetControlStatus(1)) {

			printf("Set control status failed!\n");
			return 1;
		}

		printf("Set control status success!\n");
	}
	else {

		PrintUsage();
	}

	return 0;
}

