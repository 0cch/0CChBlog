#include "NtfsParse.h"


BOOL CFixup::Fixup( PFILE_RECORD_HEADER Buf)
{
	PUSHORT CurEnd;
	PUSHORT USArray;
	USHORT USChecker;
	ULONG i;
	ULONG Count = Buf->SizeOfUS - 1;
	ULONG Offset = m_BytePerSector - sizeof(USHORT);

	USArray = (PUSHORT)(Buf->OffsetOfUS + (ULONG)Buf);
	USChecker = *USArray;
	USArray++;

	CurEnd = (PUSHORT)((ULONG)Buf + Offset);

	for (i = 0; i < Count; i++) {

		if (*CurEnd != USChecker) {

			return FALSE;
		}

		*CurEnd = USArray[i];
		CurEnd += (m_BytePerSector >> 1);
	}
	
	return TRUE;
}

BOOL CFixup::Fixup( PINDEX_RECORD_ATTRIBUTE Buf )
{
	PUSHORT CurEnd;
	PUSHORT USArray;
	USHORT USChecker;
	ULONG i;
	ULONG Count = Buf->IndexRecordHeader.SizeOfUS - 1;
	ULONG Offset = m_BytePerSector - sizeof(USHORT);

	USArray = (PUSHORT)(Buf->IndexRecordHeader.OffsetOfUS + (ULONG)Buf);
	USChecker = *USArray;
	USArray++;

	CurEnd = (PUSHORT)((ULONG)Buf + Offset);

	for (i = 0; i < Count; i++) {

		if (*CurEnd != USChecker) {

			return FALSE;
		}

		*CurEnd = USArray[i];
		CurEnd += (m_BytePerSector >> 1);
	}

	return TRUE;
}

BOOL CBitTool::SetBit( ULONGLONG Bit )
{
	ULONG ByteOffset = 0;
	ULONG BitOffset = 0;

	ByteOffset = (ULONG)(Bit / 8);
	if (ByteOffset >= m_BitSize) {

		return FALSE;
	}

	BitOffset = (ULONG)(Bit % 8);

	m_BitBuf[ByteOffset] |= (UCHAR)(1 << BitOffset);

	return TRUE;
}

BOOL CBitTool::ClearBit( ULONGLONG Bit )
{
	ULONG ByteOffset = 0;
	ULONG BitOffset = 0;

	ByteOffset = (ULONG)(Bit / 8);
	if (ByteOffset >= m_BitSize) {

		return FALSE;
	}

	BitOffset = (ULONG)(Bit % 8);

	m_BitBuf[ByteOffset] &= (UCHAR)(~(1 << BitOffset));

	return TRUE;
}

ULONG CBitTool::GetBit( ULONGLONG Bit )
{
	ULONG ByteOffset = 0;
	ULONG BitOffset = 0;

	ByteOffset = (ULONG)(Bit / 8);
	if (ByteOffset >= m_BitSize) {

		return (ULONG)-1;
	}

	BitOffset = (ULONG)(Bit % 8);

	return (m_BitBuf[ByteOffset] & (UCHAR)(1 << BitOffset)) != 0;
}

CNtfsParse::CNtfsParse()
{
	ZeroMemory(&m_NtfsBootSec, sizeof(NTFS_BOOT_SEC));
	m_VolumeHandle = 0;
	m_MftHeader = NULL;
}

CNtfsParse::~CNtfsParse()
{
	if (m_VolumeHandle != 0) {

		CloseHandle(m_VolumeHandle);
		m_VolumeHandle = 0;
	}

	if (m_MftHeader != NULL) {

		delete[] m_MftHeader;
		m_MftHeader = NULL;
	}
}

BOOL CNtfsParse::OpenVolume( CHAR ch )
{
	ULONG RetLength;
	CHAR Buffer[16] = {0};
	ULONG SectorOffset;
	CHAR FrOp;

	sprintf_s(Buffer, 16, "\\\\.\\%c:", ch);

	m_VolumeHandle = CreateFileA(Buffer, 
		GENERIC_READ, 
		FILE_SHARE_READ | FILE_SHARE_WRITE, 
		NULL, 
		OPEN_EXISTING, 
		0, 
		0);

	if (m_VolumeHandle == INVALID_HANDLE_VALUE) {

		m_VolumeHandle = NULL;
		return FALSE;
	}

	if (!ReadFile(m_VolumeHandle, &m_NtfsBootSec, sizeof(m_NtfsBootSec), &RetLength, NULL)) {

		CloseHandle(m_VolumeHandle);
		return FALSE;
	}

	m_MftBase = m_NtfsBootSec.ExBpb.MFT * 
		m_NtfsBootSec.Bpb.SectorsPerCluster * 
		m_NtfsBootSec.Bpb.BytesPerSector;

	FrOp = (CHAR)m_NtfsBootSec.ExBpb.ClustersPerFileRecordSegment;
	if (FrOp > 0) {

		m_SizeOfRecord = FrOp * m_SizeOfCluster;
	}
	else {
		m_SizeOfRecord = 1 << (-FrOp);
	}
	
	m_SizeOfCluster = m_NtfsBootSec.Bpb.SectorsPerCluster * 
		m_NtfsBootSec.Bpb.BytesPerSector;

	SectorOffset = (ULONG)(m_NtfsBootSec.ExBpb.MFT * m_NtfsBootSec.Bpb.SectorsPerCluster);

	m_MftHeader = (PFILE_RECORD_HEADER) new UCHAR[m_SizeOfRecord];

	if (!ReadSectors(SectorOffset, m_MftHeader, 1)) {

		CloseHandle(m_VolumeHandle);
		m_VolumeHandle = NULL;
		return FALSE;
	}



	return TRUE;
}

BOOL CNtfsParse::ReadSectors( ULONGLONG OffsetOfSector, PVOID Buffer, ULONG Count )
{
	BOOL Ret;
	LARGE_INTEGER MoveByte;
	ULONG BufferSize;
	ULONG RetLength;

	MoveByte.QuadPart = OffsetOfSector * m_NtfsBootSec.Bpb.BytesPerSector;
	BufferSize = Count * m_NtfsBootSec.Bpb.BytesPerSector;

	Ret = SetFilePointerEx(m_VolumeHandle, 
		MoveByte,
		NULL, 
		FILE_BEGIN);

	if (!Ret) {

		return Ret;
	}

	Ret = ReadFile(m_VolumeHandle, Buffer, BufferSize, &RetLength, NULL);

	return Ret;
}

PFILE_RECORD_HEADER CNtfsParse::GetFileRecord( ULONGLONG Ref )
{
	PUCHAR Buffer = new UCHAR[m_SizeOfRecord];
	LARGE_INTEGER MoveByte;
	BOOL Ret;
	ULONG RetLength;
	CFileRecord MftRecord(m_MftHeader);
	CFixup FixupFile(m_NtfsBootSec.Bpb.BytesPerSector);
	PCOMMON_ATTRIBUTE_HEADER Data;
	CData MftData;
	ULONGLONG VCN = 0;
	ULONGLONG LCN = 0;
	ULONG Count;
	ULONGLONG TargetVCN;
	ULONGLONG TargetLCN;
	ULONGLONG OffsetByte;
	PUCHAR ClusterBuf;

	if (Ref < MFT_METAFILE_END) {

		MoveByte.QuadPart = Ref * m_SizeOfRecord + m_MftBase;

		Ret = SetFilePointerEx(m_VolumeHandle, 
			MoveByte,
			NULL, 
			FILE_BEGIN);

		if (!Ret) {

			delete[] Buffer;
			return NULL;
		}

		Ret = ReadFile(m_VolumeHandle, Buffer, m_SizeOfRecord, &RetLength, NULL);
		if (!Ret) {

			delete[] Buffer;
			return NULL;
		}

		if (!FixupFile.Fixup((PFILE_RECORD_HEADER)Buffer)) {

			delete[] Buffer;
			return NULL;
		}
	}
	else {
		
		TargetVCN = Ref * m_SizeOfRecord / m_SizeOfCluster;
		OffsetByte = Ref * m_SizeOfRecord % m_SizeOfCluster;


		Data = MftRecord.ParseAttribute($DATA);
		if (Data == NULL) {

			delete[] Buffer;
			return NULL;
		}

		MftData = Data;
		if (!MftData.IsNonResident()) {

			delete[] Buffer;
			return NULL;
		}

		if (!MftData.GetFirstLCN(&LCN, &VCN, &Count)) {

			delete[] Buffer;
			return NULL;
		}

		do {

			if (TargetVCN >= VCN && TargetVCN < (VCN + Count)) {

				TargetLCN = TargetVCN - VCN + LCN;

				ClusterBuf = new UCHAR[m_SizeOfCluster];
				
				if (!ReadCluster(TargetLCN, ClusterBuf, 1)) {

					delete[] ClusterBuf;
					return NULL;
				}

				
				memcpy(Buffer, ClusterBuf + OffsetByte, m_SizeOfRecord);

				delete[] ClusterBuf;
				break;
			}

		} while (MftData.GetNextLCN(&LCN, &VCN, &Count));


	}

	if (*(ULONG *)Buffer != 'ELIF') {

		delete[] Buffer;
		Buffer = NULL;
	}

	return (PFILE_RECORD_HEADER)Buffer;

}

VOID CNtfsParse::ReleaseFileRecord( PFILE_RECORD_HEADER Buf )
{
	delete Buf;
}

BOOL CNtfsParse::ReadCluster( ULONGLONG LCN, PVOID Buffer, ULONG Count )
{
	BOOL Ret;
	LARGE_INTEGER MoveByte;
	ULONG BufferSize;
	ULONG RetLength;
	ULONG BytePerCluster;

	BytePerCluster = m_NtfsBootSec.Bpb.BytesPerSector * m_NtfsBootSec.Bpb.SectorsPerCluster;
	MoveByte.QuadPart = LCN * BytePerCluster;
	BufferSize = Count * BytePerCluster;

	Ret = SetFilePointerEx(m_VolumeHandle, 
		MoveByte,
		NULL, 
		FILE_BEGIN);

	if (!Ret) {

		return Ret;
	}

	Ret = ReadFile(m_VolumeHandle, Buffer, BufferSize, &RetLength, NULL);

	return Ret;
}

PINDEX_RECORD_ATTRIBUTE CNtfsParse::GetIndexRecord( ULONGLONG LCN )
{
	ULONG BytePerCluster;
	PUCHAR Buffer;
	CFixup FixupIndex(m_NtfsBootSec.Bpb.BytesPerSector);

	BytePerCluster = m_NtfsBootSec.Bpb.BytesPerSector * m_NtfsBootSec.Bpb.SectorsPerCluster;
	Buffer = new UCHAR[BytePerCluster];

	if (!ReadCluster(LCN, Buffer, m_NtfsBootSec.ExBpb.ClustersPerIndexBlock)) {

		delete Buffer;
		return NULL;
	}

	if (!FixupIndex.Fixup((PINDEX_RECORD_ATTRIBUTE)Buffer)) {

		delete Buffer;
		return NULL;
	}

	return (PINDEX_RECORD_ATTRIBUTE)Buffer;
}

VOID CNtfsParse::ReleaseIndexRecord( PINDEX_RECORD_ATTRIBUTE Buf )
{
	delete Buf;
}

CDataRun::CDataRun( PNONRESIDENT_ATTRIBUTE_HEADER Buffer )
{
	m_CurDataRun = 0;
	m_CurLCN = 0;
	m_CurVCN = 0;
	m_VCNCount = 0;
	m_AllocAttrHeader = Buffer;
}

CDataRun::CDataRun()
{
	m_CurDataRun = 0;
	m_CurLCN = 0;
	m_CurVCN = 0;
	m_VCNCount = 0;
	m_AllocAttrHeader = NULL;
}


CDataRun& CDataRun::operator=( PNONRESIDENT_ATTRIBUTE_HEADER Buffer )
{
	m_CurDataRun = 0;
	m_CurLCN = 0;
	m_CurVCN = 0;
	m_VCNCount = 0;
	m_AllocAttrHeader = Buffer;

	return *this;
}

BOOL CDataRun::GetFirstLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	UCHAR DataRunIndex;
	UCHAR CountLength;
	UCHAR LCNLength;
	ULONG CNCount;
	ULONGLONG LCNOffset;

	m_CurLCN = 0;
	m_CurVCN = m_AllocAttrHeader->StartVCN;
	m_VCNCount = m_AllocAttrHeader->LastVCN - m_AllocAttrHeader->StartVCN + 1;
	m_CurDataRun = (PUCHAR)((ULONG)m_AllocAttrHeader + m_AllocAttrHeader->DataRunOffset);

	DataRunIndex = *m_CurDataRun;

	if (DataRunIndex == 0) {

		return FALSE;
	}

	CountLength = DataRunIndex & 0x0f;
	LCNLength = (DataRunIndex >> 4) & 0x0f;
	m_CurDataRun++;

	if (CountLength > 4) {

		return FALSE;
	}

	CNCount = 0;
	memcpy(&CNCount, m_CurDataRun, CountLength);
	m_CurDataRun += CountLength;
	*Count = CNCount;

	if ((m_CurDataRun[LCNLength - 1] & 0x80) != 0) {

		LCNOffset = (ULONGLONG)-1;
	}
	else {

		LCNOffset = 0;
	}
	memcpy(&LCNOffset, m_CurDataRun, LCNLength);
	m_CurDataRun += LCNLength;

	m_CurLCN += LCNOffset;

	*LCN = m_CurLCN;

	*VCN = m_CurVCN;

	m_CurVCN += CNCount;
	if (m_CurVCN > m_VCNCount) {

		return FALSE;
	}

	return TRUE;
}

BOOL CDataRun::GetNextLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	UCHAR DataRunIndex;
	UCHAR CountLength;
	UCHAR LCNLength;
	ULONG CNCount;
	ULONGLONG LCNOffset;


	DataRunIndex = *m_CurDataRun;

	if (DataRunIndex == 0) {

		return FALSE;
	}

	CountLength = DataRunIndex & 0x0f;
	LCNLength = (DataRunIndex >> 4) & 0x0f;
	m_CurDataRun++;

	if (CountLength > 4) {

		return FALSE;
	}

	CNCount = 0;
	memcpy(&CNCount, m_CurDataRun, CountLength);
	m_CurDataRun += CountLength;
	*Count = CNCount;

	if ((m_CurDataRun[LCNLength - 1] & 0x80) != 0) {

		LCNOffset = (ULONGLONG)-1;
	}
	else {
		
		LCNOffset = 0;
	}
	
	memcpy(&LCNOffset, m_CurDataRun, LCNLength);
	m_CurDataRun += LCNLength;

	m_CurLCN += LCNOffset;

	*LCN = m_CurLCN;

	*VCN = m_CurVCN;

	m_CurVCN += CNCount;
	if (m_CurVCN > m_VCNCount) {

		return FALSE;
	}

	return TRUE;
}


CFileRecord::CFileRecord( PFILE_RECORD_HEADER Buffer )
{
	m_FileRecord = Buffer;
	m_ComAttrHeader = (PCOMMON_ATTRIBUTE_HEADER)((PUCHAR)Buffer + Buffer->OffsetOfAttr);
}

CFileRecord::CFileRecord()
{
	m_FileRecord = NULL;
	m_ComAttrHeader = NULL;
}

CFileRecord& CFileRecord::operator=( PFILE_RECORD_HEADER Buffer )
{
	m_FileRecord = Buffer;
	m_ComAttrHeader = (PCOMMON_ATTRIBUTE_HEADER)((PUCHAR)Buffer + Buffer->OffsetOfAttr);

	return *this;
}

PCOMMON_ATTRIBUTE_HEADER CFileRecord::ParseAttribute( ULONG AttributeType )
{
	ULONG EndLimit = (ULONG)m_ComAttrHeader + m_FileRecord->RealSize;

	for (m_CurBase = (ULONG)m_ComAttrHeader; m_CurBase < EndLimit;) {

		if (((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->Type == AttributeType) {

			return (PCOMMON_ATTRIBUTE_HEADER)m_CurBase;
		}
		else if (((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->Type == $END_ATTRIBUTE) {

			break;
		}

		m_CurBase += ((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->TotalSize;

	}

	return NULL;
}

PCOMMON_ATTRIBUTE_HEADER CFileRecord::ParseNextAttribute( ULONG AttributeType )
{
	ULONG EndLimit = (ULONG)m_ComAttrHeader + m_FileRecord->RealSize;
	m_CurBase += ((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->TotalSize;

	for (; m_CurBase < EndLimit;) {

		if (((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->Type == AttributeType) {

			return (PCOMMON_ATTRIBUTE_HEADER)m_CurBase;
		}
		else if (((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->Type == $END_ATTRIBUTE) {

			break;
		}

		m_CurBase += ((PCOMMON_ATTRIBUTE_HEADER)m_CurBase)->TotalSize;

	}

	return NULL;
}

CIndexRoot::CIndexRoot( PCOMMON_ATTRIBUTE_HEADER Buffer )
{
	m_IndexAttrHeader = (PRESIDENT_ATTRIBUTE_HEADER)Buffer;
	m_IndexRootAttr = (PINDEX_ROOT_ATTRIBUTE)((PUCHAR)Buffer + 
		m_IndexAttrHeader->AttrOffset);
}

CIndexRoot::CIndexRoot()
{
	m_IndexAttrHeader = NULL;
	m_IndexRootAttr = NULL;
}


CIndexRoot& CIndexRoot::operator=( PCOMMON_ATTRIBUTE_HEADER Buffer )
{
	m_IndexAttrHeader = (PRESIDENT_ATTRIBUTE_HEADER)Buffer;
	m_IndexRootAttr = (PINDEX_ROOT_ATTRIBUTE)((PUCHAR)Buffer + 
		m_IndexAttrHeader->AttrOffset);

	return *this;
}


PINDEX_ENTRY CIndexRoot::FindFirstIndexEntry()
{
	m_CurrentEntry = (PINDEX_ENTRY)((ULONG)&m_IndexRootAttr->IndexHeader + 
				m_IndexRootAttr->IndexHeader.EntryOffset);

	m_EndLimit = (ULONG)m_CurrentEntry + m_IndexRootAttr->IndexHeader.TotalEntrySize;

	return m_CurrentEntry;
}

PINDEX_ENTRY CIndexRoot::FindNextIndexEntry()
{
	if (m_CurrentEntry->Flags & LAST_INDEX_ENTRY) {

		return NULL;
	}

	m_CurrentEntry = (PINDEX_ENTRY)((ULONG)m_CurrentEntry + (ULONG)m_CurrentEntry->Size);

	if ((ULONG)m_CurrentEntry < m_EndLimit) {

		return m_CurrentEntry;
	}

	return NULL;
}


CIndexRecord::CIndexRecord( PINDEX_RECORD_ATTRIBUTE Buffer )
{
	m_IndexBlockHeader = Buffer;
	m_CurrentEntry = 0;
	m_EndLimit = 0;
}

CIndexRecord::CIndexRecord()
{
	m_IndexBlockHeader = NULL;
	m_CurrentEntry = 0;
	m_EndLimit = 0;
}

CIndexRecord& CIndexRecord::operator=( PINDEX_RECORD_ATTRIBUTE Buffer )
{
	m_IndexBlockHeader = Buffer;
	m_CurrentEntry = 0;
	m_EndLimit = 0;

	return *this;
}

PINDEX_ENTRY CIndexRecord::FindFirstIndexEntry()
{
	m_CurrentEntry = (PINDEX_ENTRY)((ULONG)&m_IndexBlockHeader->IndexHeader + 
		m_IndexBlockHeader->IndexHeader.EntryOffset);

	m_EndLimit = (ULONG)m_CurrentEntry + m_IndexBlockHeader->IndexHeader.TotalEntrySize;

	return m_CurrentEntry;
}

PINDEX_ENTRY CIndexRecord::FindNextIndexEntry()
{
	if (m_CurrentEntry->Flags & LAST_INDEX_ENTRY) {

		return NULL;
	}

	m_CurrentEntry = (PINDEX_ENTRY)((ULONG)m_CurrentEntry + (ULONG)m_CurrentEntry->Size);

	if ((ULONG)m_CurrentEntry < m_EndLimit) {

		return m_CurrentEntry;
	}

	return NULL;
}


PATTRIBUTE_LIST_ENTRY CAttributeList::FindFirstEntry(CNtfsParse *NtfsParse)
{

	m_CurSize = 0;

	if (!IsNonResident()) {

		UNREFERENCED_PARAMETER(NtfsParse);
		ParseResident();

		return m_CurrentEntry;

	}
	else {

		if (!ParseNonResident(NtfsParse)) {

			return NULL;
		}

		return m_CurrentEntry;

	}
}

PATTRIBUTE_LIST_ENTRY CAttributeList::FindNextEntry()
{
	m_CurSize += m_CurrentEntry->RecordSize;

	if (m_CurSize >= m_AttrSize) {

		return NULL;
	}

	m_CurrentEntry = (PATTRIBUTE_LIST_ENTRY)((ULONG)m_CurrentEntry + m_CurrentEntry->RecordSize);

	return m_CurrentEntry;
}

BOOL CAttributeList::ParseNonResident(CNtfsParse *NtfsParse)
{
	ULONGLONG i = 0;
	ULONGLONG LCN = 0, VCN = 0;
	ULONG Count;
	ULONGLONG AllocSize = m_AttrHeader->NonResidentHeader.AllocSize;
	PUCHAR CurPos;

	m_AttrSize = m_AttrHeader->NonResidentHeader.RealSize;

	
	if (m_EntryHeader != 0) {

		delete[] m_EntryHeader;
		m_EntryHeader = 0;
	}

	m_EntryHeader = (PATTRIBUTE_LIST_ENTRY)new UCHAR[(ULONG)AllocSize];
	CurPos = (PUCHAR)m_EntryHeader;

	if (!GetFirstLCN(&LCN, &VCN, &Count)) {

		delete[] m_EntryHeader;
		m_EntryHeader = 0;
		return FALSE;
	}

	if (!NtfsParse->ReadCluster(LCN, CurPos, Count)) {

		delete[] m_EntryHeader;
		m_EntryHeader = 0;
		return FALSE;
	}
	
	CurPos += Count * NtfsParse->GetClusterSize();

	while (GetNextLCN(&LCN, &VCN, &Count)) {

		if (!NtfsParse->ReadCluster(LCN, CurPos, Count)) {

			delete[] m_EntryHeader;
			m_EntryHeader = 0;
			return FALSE;
		}

		CurPos += Count * NtfsParse->GetClusterSize();
	}

	m_CurrentEntry = m_EntryHeader;

	return TRUE;
}

BOOL CAttributeList::GetFirstLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	if (!IsNonResident()) {

		return FALSE;
	}

	return CDataRun::GetFirstLCN(LCN, VCN, Count);
}

BOOL CAttributeList::GetNextLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	if (!IsNonResident()) {

		return FALSE;
	}

	return CDataRun::GetNextLCN(LCN, VCN, Count);
}

BOOL CBitmap::Parse( CNtfsParse *NtfsParse )
{
	ULONGLONG AllocSize;
	PUCHAR CurPos;
	ULONGLONG LCN = 0, VCN = 0;
	ULONG Count;

	if (!IsNonResident()) {

		UNREFERENCED_PARAMETER(NtfsParse);

		m_Bitmap = (PUCHAR)(m_BitmapHeader->ResidentHeader.AttrOffset + (ULONG)m_BitmapHeader);
		m_AttrSize = m_BitmapHeader->ResidentHeader.AttrSize;

		CBitTool::ReInit(m_Bitmap, (ULONG)m_AttrSize);

		return TRUE;
	}
	else {

		m_AttrSize = m_BitmapHeader->NonResidentHeader.RealSize;
		AllocSize = m_BitmapHeader->NonResidentHeader.AllocSize;
		m_AllocBuffer = new UCHAR[(ULONG)AllocSize];

		CurPos = (PUCHAR)m_AllocBuffer;

		if (!GetFirstLCN(&LCN, &VCN, &Count)) {

			delete[] m_AllocBuffer;
			m_AllocBuffer = 0;
			return FALSE;
		}

		if (!NtfsParse->ReadCluster(LCN, CurPos, Count)) {

			delete[] m_AllocBuffer;
			m_AllocBuffer = 0;
			return FALSE;
		}

		CurPos += Count * NtfsParse->GetClusterSize();

		while (GetNextLCN(&LCN, &VCN, &Count)) {

			if (!NtfsParse->ReadCluster(LCN, CurPos, Count)) {

				delete[] m_AllocBuffer;
				m_AllocBuffer = 0;
				return FALSE;
			}

			CurPos += Count * NtfsParse->GetClusterSize();
		}

		m_Bitmap = m_AllocBuffer;

		CBitTool::ReInit(m_Bitmap, (ULONG)m_AttrSize);

		return TRUE;

	}
}

BOOL CBitmap::GetFirstLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	if (!IsNonResident()) {

		return FALSE;
	}

	return CDataRun::GetFirstLCN(LCN, VCN, Count);
}

BOOL CBitmap::GetNextLCN( ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count )
{
	if (!IsNonResident()) {

		return FALSE;
	}

	return CDataRun::GetNextLCN(LCN, VCN, Count);
}