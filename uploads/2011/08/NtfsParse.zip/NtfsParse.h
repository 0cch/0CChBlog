#ifndef __NTFS_PARSE_H__
#define __NTFS_PARSE_H__

#include <stdio.h>
#include <windows.h>

#define		MFT_ROOT_REF	5


#define	 	$STANDARD_INFORMATION 		0x00000010
#define	 	$ATTRIBUTE_LIST       		0x00000020
#define	 	$FILE_NAME            		0x00000030
#define		$OBJECT_ID            		0x00000040
#define	 	$SECURITY_DESCRIPTOR  		0x00000050
#define	 	$VOLUME_NAME          		0x00000060
#define	 	$VOLUME_INFORMATION   		0x00000070
#define	 	$DATA                 		0x00000080
#define	 	$INDEX_ROOT           		0x00000090
#define	 	$INDEX_ALLOCATION     		0x000000A0
#define	 	$BITMAP               		0x000000B0
#define		$REPARSE_POINT        		0x000000C0
#define	 	$EA_INFORMATION       		0x000000D0
#define	 	$EA                   		0x000000E0
#define		$LOGGED_UTILITY_STREAM		0x00000100
#define		$END_ATTRIBUTE				0xFFFFFFFF
 

#define		INDEX_ENTRY_TO_SUB_NODE		1
#define		LAST_INDEX_ENTRY			2


#define		FILENAME_FLAG_READONLY		0x00000001
#define		FILENAME_FLAG_HIDDEN		0x00000002
#define		FILENAME_FLAG_SYSTEM		0x00000004
#define		FILENAME_FLAG_ARCHIVE		0x00000020
#define		FILENAME_FLAG_DEVICE		0x00000040
#define		FILENAME_FLAG_NORMAL		0x00000080
#define		FILENAME_FLAG_TEMP			0x00000100
#define		FILENAME_FLAG_SPARSE		0x00000200
#define		FILENAME_FLAG_REPARSE		0x00000400
#define		FILENAME_FLAG_COMPRESSED	0x00000800
#define		FILENAME_FLAG_OFFLINE		0x00001000
#define		FILENAME_FLAG_NCI			0x00002000
#define		FILENAME_FLAG_ENCRYPTED		0x00004000
#define		FILENAME_FLAG_DIRECTORY		0x10000000
#define		FILENAME_FLAG_INDEXVIEW		0x20000000

#define		FILENAME_NAMESPACE_POSIX	0x00
#define		FILENAME_NAMESPACE_WIN32	0x01
#define		FILENAME_NAMESPACE_DOS		0x02


#define		MFT_RECORD_INDEX_MASK		0x0000ffffffffffff
#define		MFT_METAFILE_END			24

#define 	SMALL_INDEX					0x00
#define		LARGE_INDEX					0x01

#pragma pack(push, 1)

typedef struct _NTFS_UNICODE_STRING
{
	UCHAR		NameLength;		// Filename length in characters
	UCHAR		NameSpace;		// Filename space
	USHORT		Name[1];		// Filename

} NTFS_UNICODE_STRING, *PNTFS_UNICODE_STRING;

typedef struct _NTFS_BPB {
	USHORT	BytesPerSector;
	UCHAR	SectorsPerCluster;
	USHORT	ReservedSectors;
	UCHAR	NumberOfFATs;		// always 0
	USHORT	RootEntries;		// always 0
	USHORT	SmallSectors;		// not used by NTFS
	UCHAR	MediaDescriptor;
	USHORT 	SectorsPerFAT;		// always 0
	USHORT	SectorsPerTrack;
	USHORT	NumberOfHeads;
	ULONG	HiddenSectors;
	ULONG	LargeSectors;		//	not used by NTFS
} NTFS_BPB, *PNTFS_BPB;

typedef struct _NTFS_EXBPB {	// Extended BIOS parameter block for FAT16
	ULONG 		Reserved;		// not used by NTFS
	ULONGLONG	TotalSectors;
	ULONGLONG	MFT;
	ULONGLONG	MFTMirr;
	ULONG		ClustersPerFileRecordSegment;
	ULONG		ClustersPerIndexBlock;
	ULONGLONG	VolumeSerialNumber;
	ULONG		Checksum;
} NTFS_EXBPB, *PNTFS_EXBPB;

typedef struct _NTFS_BOOT_SEC {
	UCHAR		JumpInstruction[3];
	UCHAR		OemID[8];
	NTFS_BPB	Bpb;
	NTFS_EXBPB	ExBpb;
	UCHAR		BootstrapCode[426];
	UCHAR		EndOfSector[2];

} NTFS_BOOT_SEC, *PNTFS_BOOT_SEC;

typedef struct _FILE_RECORD_HEADER {
	UCHAR		Signature[4];		// Signature "FILE"
	USHORT		OffsetOfUS;			// offset to fixup pattern
	USHORT		SizeOfUS;			// Size of fixup-list +1
	ULONGLONG	LogSeqNumber;		// log file seq number
	USHORT		Sequence;			// sequence nr in MFT
	USHORT		HardLinks;			// Hard-link count
	USHORT		OffsetOfAttr;		// Offset to seq of Attributes
	USHORT		Flags;				// 0x01 = NonRes; 0x02 = Dir
	ULONG		RealSize;			// Real size of the record
	ULONG		AllocSize;;			// Allocated size of the record
	ULONGLONG	RefToBase;			// ptr to base MFT rec or 0
	USHORT		NextAttrID;			// Minimum Identificator +1
	USHORT		Padding;			// Current fixup pattern
	ULONG		MFTRecNumber;		// Number of this MFT Record
	// followed by resident and
	// part of non-res attributes

} FILE_RECORD_HEADER, *PFILE_RECORD_HEADER;

typedef struct _COMMON_ATTRIBUTE_HEADER
{
	ULONG		Type;			// Attribute Type
	ULONG		TotalSize;		// Length (including this header)
	UCHAR		NonResident;	// 0 - resident, 1 - non resident
	UCHAR		NameLength;		// name length in words
	USHORT		NameOffset;		// offset to the name
	USHORT		Flags;			// Flags
	USHORT		Id;				// Attribute Id

} COMMON_ATTRIBUTE_HEADER, *PCOMMON_ATTRIBUTE_HEADER;

typedef struct _RESIDENT_ATTRIBUTE_HEADER {

	COMMON_ATTRIBUTE_HEADER		Header;			// Common data structure
	ULONG						AttrSize;		// Length of the attribute body
	USHORT						AttrOffset;		// Offset to the Attribute
	UCHAR						IndexedFlag;	// Indexed flag
	UCHAR						Padding;		// Padding

} RESIDENT_ATTRIBUTE_HEADER, *PRESIDENT_ATTRIBUTE_HEADER;

typedef struct _NONRESIDENT_ATTRIBUTE_HEADER {

	COMMON_ATTRIBUTE_HEADER		Header;			// Common data structure
	ULONGLONG					StartVCN;		// Starting VCN
	ULONGLONG					LastVCN;		// Last VCN
	USHORT						DataRunOffset;	// Offset to the Data Runs
	USHORT						CompUnitSize;	// Compression unit size
	ULONG						Padding;		// Padding
	ULONGLONG					AllocSize;		// Allocated size of the attribute
	ULONGLONG					RealSize;		// Real size of the attribute
	ULONGLONG					IniSize;		// Initialized data size of the stream 

} NONRESIDENT_ATTRIBUTE_HEADER, *PNONRESIDENT_ATTRIBUTE_HEADER;


typedef struct _STANDARD_INFORMATION_ATTRIBUTE {

	ULONGLONG	CreateTime;		// File creation time
	ULONGLONG	AlterTime;		// File altered time
	ULONGLONG	MFTTime;		// MFT changed time
	ULONGLONG	ReadTime;		// File read time
	ULONG		Permission;		// Dos file permission
	ULONG		MaxVersionNo;	// Maxim number of file versions
	ULONG		VersionNo;		// File version number
	ULONG		ClassId;		// Class Id
	ULONG		OwnerId;		// Owner Id
	ULONG		SecurityId;		// Security Id
	ULONGLONG	QuotaCharged;	// Quota charged
	ULONGLONG	USN;			// USN Journel
} STANDARD_INFORMATION_ATTRIBUTE, *PSTANDARD_INFORMATION_ATTRIBUTE;


typedef struct _FILE_NAME_ATTRIBUTE {

	ULONGLONG	ParentRef;		// File reference to the parent directory
	ULONGLONG	CreateTime;		// File creation time
	ULONGLONG	AlterTime;		// File altered time
	ULONGLONG	MFTTime;		// MFT changed time
	ULONGLONG	ReadTime;		// File read time
	ULONGLONG	AllocSize;		// Allocated size of the file
	ULONGLONG	RealSize;		// Real size of the file
	ULONG		Flags;			// Flags
	ULONG		ER;				// Used by EAs and Reparse
	UCHAR		NameLength;		// Filename length in characters
	UCHAR		NameSpace;		// Filename space
	USHORT		Name[1];		// Filename
} FILE_NAME_ATTRIBUTE, *PFILE_NAME_ATTRIBUTE;


typedef struct _INDEX_ROOT {

	ULONG		AttrType;			// Attribute type (ATTR_TYPE_FILE_NAME: Directory, 0: Index View)
	ULONG		CollRule;			// Collation rule
	ULONG		IBSize;				// Size of index block
	UCHAR		ClustersPerIB;		// Clusters per index block (same as BPB?)
	UCHAR		Padding[3];			// Padding

} INDEX_ROOT, *PINDEX_ROOT;


typedef struct _INDEX_HEADER {

	ULONG		EntryOffset;		// Offset to the first index entry, relative to this address(0x10)
	ULONG		TotalEntrySize;		// Total size of the index entries
	ULONG		AllocEntrySize;		// Allocated size of the index entries
	UCHAR		Flags;				// Flags
	UCHAR		Padding2[3];		// Padding

} INDEX_HEADER, *PINDEX_HEADER;


typedef struct _INDEX_ROOT_ATTRIBUTE {

	INDEX_ROOT					IndexRoot;
	INDEX_HEADER				IndexHeader;

} INDEX_ROOT_ATTRIBUTE, *PINDEX_ROOT_ATTRIBUTE;


typedef struct _ATTRIBUTE_LIST_ENTRY {

	ULONG		AttrType;		// Attribute type
	USHORT		RecordSize;		// Record length
	UCHAR		NameLength;		// Name length in characters
	UCHAR		NameOffset;		// Name offset
	ULONGLONG	StartVCN;		// Start VCN
	ULONGLONG	BaseRef;		// Base file reference to the attribute
	USHORT		AttrId;			// Attribute Id

} ATTRIBUTE_LIST_ENTRY, *PATTRIBUTE_LIST_ENTRY;


typedef union _ATTRIBUTE_LIST_HEADER {

	COMMON_ATTRIBUTE_HEADER CommHeader;
	RESIDENT_ATTRIBUTE_HEADER ResidentHeader;
	NONRESIDENT_ATTRIBUTE_HEADER NonResidentHeader;

} ATTRIBUTE_LIST_HEADER, *PATTRIBUTE_LIST_HEADER;

typedef struct _INDEX_ENTRY {

	ULONGLONG				FileReference;		// Low 6B: MFT record index, High 2B: MFT record sequence number
	USHORT					Size;				// Length of the index entry
	USHORT					FilenameOffset;		// Offset of file name
	UCHAR					Flags;				// Flags
	UCHAR					Padding[3];			// Padding
	UCHAR					Stream[1];			// Stream

} INDEX_ENTRY, *PINDEX_ENTRY;

typedef struct _INDEX_RECORD_HEADER {

	ULONG		Magic;			// "INDX"
	USHORT		OffsetOfUS;		// Offset of Update Sequence
	USHORT		SizeOfUS;		// Size in words of Update Sequence Number & Array
	ULONGLONG	LSN;			// $LogFile Sequence Number
	ULONGLONG	VCN;			// VCN of this index block in the index allocation

} INDEX_RECORD_HEADER, *PINDEX_RECORD_HEADER;

typedef struct _INDEX_RECORD_ATTRIBUTE {

	INDEX_RECORD_HEADER IndexRecordHeader;
	INDEX_HEADER IndexHeader;

} INDEX_RECORD_ATTRIBUTE, *PINDEX_RECORD_ATTRIBUTE;


typedef union _BITMAP_HEADER {

	COMMON_ATTRIBUTE_HEADER CommHeader;
	RESIDENT_ATTRIBUTE_HEADER ResidentHeader;
	NONRESIDENT_ATTRIBUTE_HEADER NonResidentHeader;

} BITMAP_HEADER, *PBITMAP_HEADER;

#pragma pack(pop)


class CNtfsUnicodeString {

public:
	CNtfsUnicodeString(UCHAR Length)
	{ 
		PUCHAR p = new UCHAR[Length * sizeof(WCHAR) + sizeof(NTFS_UNICODE_STRING)];
		ZeroMemory(p, Length * sizeof(WCHAR) + sizeof(NTFS_UNICODE_STRING));

		m_String = (PNTFS_UNICODE_STRING)p;
		m_String->NameLength = Length;
		m_Length = Length;
	}
	~CNtfsUnicodeString() {delete m_String;}

	PNTFS_UNICODE_STRING GetString() {return m_String;}
	VOID Empty()
	{
		ZeroMemory(m_String, m_Length * sizeof(WCHAR) + sizeof(NTFS_UNICODE_STRING));
		m_String->NameLength = m_Length;
	}

private:

	PNTFS_UNICODE_STRING m_String;
	UCHAR m_Length;
};


class CFixup {

public:
	CFixup(ULONG BytePerSector) {m_BytePerSector = BytePerSector;}
	~CFixup() {}

	BOOL Fixup(PFILE_RECORD_HEADER Buf);
	BOOL Fixup(PINDEX_RECORD_ATTRIBUTE Buf);

private:
	ULONG m_BytePerSector;
};

class CBitTool {
public:
	CBitTool()
	{
		m_BitBuf = 0;
		m_BitSize = 0;
	}

	CBitTool(PVOID Buf, ULONG Size)
	{
		m_BitBuf = (PUCHAR)Buf;
		m_BitSize = Size;
	}

	~CBitTool() {}

	VOID ReInit(PVOID Buf, ULONG Size)
	{
		m_BitBuf = (PUCHAR)Buf;
		m_BitSize = Size;
	}

	BOOL SetBit(ULONGLONG Bit);
	BOOL ClearBit(ULONGLONG Bit);
	ULONG GetBit(ULONGLONG Bit);


private:

	PUCHAR m_BitBuf;
	ULONG m_BitSize;
};

class CNtfsParse {

public:

	CNtfsParse();
	~CNtfsParse();

	BOOL OpenVolume(CHAR ch);
	BOOL ReadSectors(ULONGLONG OffsetOfSector, PVOID Buffer, ULONG Count);
	PFILE_RECORD_HEADER GetFileRecord(ULONGLONG Ref);
	VOID ReleaseFileRecord(PFILE_RECORD_HEADER Buf);
	BOOL ReadCluster(ULONGLONG LCN, PVOID Buffer, ULONG Count);
	PINDEX_RECORD_ATTRIBUTE GetIndexRecord(ULONGLONG LCN);
	VOID ReleaseIndexRecord(PINDEX_RECORD_ATTRIBUTE Buf);
	ULONG GetRecordSize() {return m_SizeOfRecord;}
	ULONG GetClusterSize() {return m_SizeOfCluster;}

private:

	NTFS_BOOT_SEC m_NtfsBootSec;
	HANDLE m_VolumeHandle;
	PFILE_RECORD_HEADER m_MftHeader;
	ULONG m_SizeOfRecord;
	ULONG m_SizeOfCluster;
	ULONGLONG m_MftBase;

};


class CDataRun {
public:

	CDataRun();
	CDataRun(PNONRESIDENT_ATTRIBUTE_HEADER Buffer);
	~CDataRun() {}

	CDataRun& operator = (PNONRESIDENT_ATTRIBUTE_HEADER Buffer);

	BOOL GetFirstLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);
	BOOL GetNextLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);

private:

	PNONRESIDENT_ATTRIBUTE_HEADER m_AllocAttrHeader;
	PUCHAR m_CurDataRun;
	ULONGLONG m_CurLCN;
	ULONGLONG m_CurVCN;
	ULONGLONG m_VCNCount;
};



class CFileRecord {

public:

	CFileRecord();
	CFileRecord(PFILE_RECORD_HEADER Buffer);
	~CFileRecord() {}

	CFileRecord& operator = (PFILE_RECORD_HEADER Buffer);
	BOOL operator == (PFILE_RECORD_HEADER Buffer) {return m_FileRecord == Buffer;}
	operator PFILE_RECORD_HEADER() const {return m_FileRecord;}

	PCOMMON_ATTRIBUTE_HEADER ParseAttribute(ULONG AttributeType);
	PCOMMON_ATTRIBUTE_HEADER ParseNextAttribute(ULONG AttributeType);

private:
	PFILE_RECORD_HEADER m_FileRecord;
	PCOMMON_ATTRIBUTE_HEADER m_ComAttrHeader;
	ULONG m_CurBase;


};


class CIndexRoot {

public:

	CIndexRoot();
	CIndexRoot(PCOMMON_ATTRIBUTE_HEADER Buffer);
	~CIndexRoot() {}

	CIndexRoot& operator = (PCOMMON_ATTRIBUTE_HEADER Buffer);

	PINDEX_ENTRY FindFirstIndexEntry();
	PINDEX_ENTRY FindNextIndexEntry();

	BOOL IsLargeIndex() {return m_IndexRootAttr->IndexHeader.Flags;}

private:

	PRESIDENT_ATTRIBUTE_HEADER m_IndexAttrHeader;
	PINDEX_ROOT_ATTRIBUTE m_IndexRootAttr;
	PINDEX_ENTRY m_CurrentEntry;
	ULONG m_EndLimit;
};

class CIndexAlloc : public CDataRun {

public:

	CIndexAlloc() : CDataRun() {};
	CIndexAlloc(PCOMMON_ATTRIBUTE_HEADER Buffer) 
		: CDataRun((PNONRESIDENT_ATTRIBUTE_HEADER)Buffer) {};
	~CIndexAlloc() {}


};


class CIndexRecord {

public:

	CIndexRecord();
	CIndexRecord(PINDEX_RECORD_ATTRIBUTE Buffer);
	~CIndexRecord() {}

	CIndexRecord& operator = (PINDEX_RECORD_ATTRIBUTE Buffer);

	PINDEX_ENTRY FindFirstIndexEntry();
	PINDEX_ENTRY FindNextIndexEntry();

private:

	PINDEX_RECORD_ATTRIBUTE m_IndexBlockHeader;
	PINDEX_ENTRY m_CurrentEntry;
	ULONG m_EndLimit;
};


class CIndexEntry {

public:

	CIndexEntry() {m_IndexEntry = NULL;}
	CIndexEntry(PINDEX_ENTRY IndexEntry) {m_IndexEntry = IndexEntry;}
	~CIndexEntry() {}

	CIndexEntry& operator = (PINDEX_ENTRY IndexEntry) 
	{
		m_IndexEntry = IndexEntry;
		return *this;
	}
	
	
	BOOL IsVaild() 
	{
		return ((m_IndexEntry->Flags & LAST_INDEX_ENTRY) != 0) || 
			((m_IndexEntry->Flags & INDEX_ENTRY_TO_SUB_NODE) != 0);
	}

	BOOL IsEndNote() {return ((m_IndexEntry->Flags & LAST_INDEX_ENTRY) != 0);}
	BOOL HasSubNode() {return ((m_IndexEntry->Flags & INDEX_ENTRY_TO_SUB_NODE) != 0);}
	BOOL HasFileName()
	{
		if (IsEndNote()) {

			return FALSE;
		}

		if (m_IndexEntry->FilenameOffset == 0) {

			return FALSE;
		}

		return TRUE;
	}

	PFILE_NAME_ATTRIBUTE GetFileNameAttribute() 
	{
		if (!HasFileName()) {

			return NULL;
		}

		return (PFILE_NAME_ATTRIBUTE)m_IndexEntry->Stream;
	}

private:

	PINDEX_ENTRY m_IndexEntry;
};


class CFileName {

public:
	CFileName() {m_FileNameAttr = NULL;}
	CFileName(PFILE_NAME_ATTRIBUTE FileNameAttr) {m_FileNameAttr = FileNameAttr;}
	CFileName(PRESIDENT_ATTRIBUTE_HEADER FileNameAttr) 
	{
		m_FileNameAttr = (PFILE_NAME_ATTRIBUTE)(FileNameAttr->AttrOffset + (PUCHAR)FileNameAttr);
	}
	~CFileName() {}

	CFileName& operator = (PFILE_NAME_ATTRIBUTE FileNameAttr) 
	{
		m_FileNameAttr = FileNameAttr;
		return *this;;
	}

	CFileName& operator = (PRESIDENT_ATTRIBUTE_HEADER FileNameAttr) 
	{
		if (FileNameAttr == NULL) {

			m_FileNameAttr = NULL;
		}
		else {

			m_FileNameAttr = (PFILE_NAME_ATTRIBUTE)(FileNameAttr->AttrOffset + (PUCHAR)FileNameAttr);
		}
		return *this;;
	}

	BOOL operator == (PFILE_NAME_ATTRIBUTE FileNameAttr)
	{
		return m_FileNameAttr == FileNameAttr;
	}

	UCHAR GetFileNameLength()
	{
		return m_FileNameAttr->NameLength;
	}

	BOOL GetFileName(PNTFS_UNICODE_STRING FileName)
	{
		if (m_FileNameAttr->NameLength == 0 || 
			m_FileNameAttr->Name[0] == 0) {

				return FALSE;
		}

		FileName->NameSpace = m_FileNameAttr->NameSpace;

		if (FileName->NameLength > m_FileNameAttr->NameLength) {

			FileName->NameLength = m_FileNameAttr->NameLength;
		}
		
		memcpy(FileName->Name, m_FileNameAttr->Name, FileName->NameLength * sizeof(WCHAR));

		return TRUE;
	}

	ULONG GetFlags() {return m_FileNameAttr->Flags;}

	ULONGLONG GetRealSize() {return m_FileNameAttr->RealSize;}

private:

	PFILE_NAME_ATTRIBUTE m_FileNameAttr;
};


class CData : public CDataRun {

public:
	
	CData() {m_ComHeader = NULL;}
	CData(PCOMMON_ATTRIBUTE_HEADER Buf) 
		: CDataRun((PNONRESIDENT_ATTRIBUTE_HEADER)Buf) 
	{
		m_ComHeader = Buf;
	}
	~CData() {}

	CData& operator = (PCOMMON_ATTRIBUTE_HEADER Buffer) 
	{
		m_ComHeader = Buffer;
		CDataRun::operator = ((PNONRESIDENT_ATTRIBUTE_HEADER)Buffer);

		return *this;
	}

	BOOL GetFirstLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count)
	{
		if (!IsNonResident()) {

			return FALSE;
		}

		return CDataRun::GetFirstLCN(LCN, VCN, Count);
	}

	BOOL GetNextLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count)
	{
		if (!IsNonResident()) {

			return FALSE;
		}

		return CDataRun::GetNextLCN(LCN, VCN, Count);
	}

	BOOL IsNonResident() {return m_ComHeader->NonResident;}
	BOOL GetResidentData(PVOID Buf, ULONG Size)
	{
		if (IsNonResident()) {

			return FALSE;
		}

		PRESIDENT_ATTRIBUTE_HEADER Header = (PRESIDENT_ATTRIBUTE_HEADER)m_ComHeader;
		ULONG ReadLength = Size > Header->AttrSize ? Header->AttrSize : Size;
		PUCHAR BufStart = (PUCHAR)Header + Header->AttrOffset;

		memcpy(Buf, BufStart, ReadLength);

		return TRUE;
	}

private:

	PCOMMON_ATTRIBUTE_HEADER m_ComHeader;

};



class CAttributeList : CDataRun {

public:
	CAttributeList() : CDataRun()
	{
		m_AttrHeader = NULL; 
		m_AttrSize = 0;
		m_EntryHeader = 0;
		m_CurSize = 0;
	}

	CAttributeList(PCOMMON_ATTRIBUTE_HEADER Buf) : CDataRun((PNONRESIDENT_ATTRIBUTE_HEADER)Buf)
	{
		m_AttrHeader = (PATTRIBUTE_LIST_HEADER)Buf;
		m_AttrSize = 0;
		m_EntryHeader = 0;
		m_CurSize = 0;
	}
	~CAttributeList() 
	{
		if (m_EntryHeader != 0) {

			delete[] m_EntryHeader;
			m_EntryHeader = 0;
		}
	}

	CAttributeList& operator = (PCOMMON_ATTRIBUTE_HEADER Buf)
	{
		m_AttrHeader = (PATTRIBUTE_LIST_HEADER)Buf;
		m_AttrSize = 0;
		m_EntryHeader = 0;
		m_CurSize = 0;
		CDataRun::operator = ((PNONRESIDENT_ATTRIBUTE_HEADER)Buf);
	}

	BOOL IsNonResident()
	{
		return m_AttrHeader->CommHeader.NonResident;
	}

	PATTRIBUTE_LIST_ENTRY FindFirstEntry(CNtfsParse *NtfsParse);
	PATTRIBUTE_LIST_ENTRY FindNextEntry();

	BOOL GetFirstLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);
	BOOL GetNextLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);

private:

	VOID ParseResident() 
	{
		m_CurrentEntry = (PATTRIBUTE_LIST_ENTRY)
			(m_AttrHeader->ResidentHeader.AttrOffset + (ULONG)m_AttrHeader);

		m_AttrSize = m_AttrHeader->ResidentHeader.AttrSize;
	}

	BOOL ParseNonResident(CNtfsParse *NtfsParse);

	PATTRIBUTE_LIST_HEADER m_AttrHeader;
	PATTRIBUTE_LIST_ENTRY m_CurrentEntry;
	PATTRIBUTE_LIST_ENTRY m_EntryHeader;
	ULONGLONG m_AttrSize;
	ULONGLONG m_CurSize;

};


class CBitmap : CBitTool, CDataRun {

public:
	CBitmap() : CBitTool(), CDataRun()
	{
		m_AttrSize = 0;
		m_Bitmap = NULL;
		m_AllocBuffer = NULL;
		m_BitmapHeader = NULL;
	}

	CBitmap(PCOMMON_ATTRIBUTE_HEADER Buf) 
		: CBitTool(), CDataRun((PNONRESIDENT_ATTRIBUTE_HEADER)Buf)
	{
		m_AttrSize = 0;
		m_Bitmap = NULL;
		m_AllocBuffer = NULL;
		m_BitmapHeader = (PBITMAP_HEADER)Buf;
	}

	~CBitmap() 
	{
		if (m_AllocBuffer != NULL) {

			delete[] m_AllocBuffer;
			m_AllocBuffer = NULL;
		}
	}

	CBitmap& operator = (PCOMMON_ATTRIBUTE_HEADER Buf)
	{
		m_AttrSize = 0;
		m_Bitmap = NULL;
		m_AllocBuffer = NULL;
		m_BitmapHeader = (PBITMAP_HEADER)Buf;

		CDataRun::operator = ((PNONRESIDENT_ATTRIBUTE_HEADER)Buf);
		return *this;
	}

	BOOL operator == (PCOMMON_ATTRIBUTE_HEADER Buf)
	{
		return m_BitmapHeader == (PBITMAP_HEADER)Buf;
	}

	BOOL IsNonResident() {return m_BitmapHeader->CommHeader.NonResident;}
	BOOL Parse(CNtfsParse *NtfsParse);

private:

	BOOL GetFirstLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);
	BOOL GetNextLCN(ULONGLONG *LCN, ULONGLONG *VCN, ULONG *Count);

	
	PBITMAP_HEADER m_BitmapHeader;
	PUCHAR m_Bitmap;
	PUCHAR m_AllocBuffer;
	ULONGLONG m_AttrSize;
};


#endif