#include "stdafx.h"
#include "EventSink.h"


STDMETHODIMP_(ULONG) EventSink::AddRef()
{
	return InterlockedIncrement(&m_lRef);
}

STDMETHODIMP_(ULONG) EventSink::Release()
{
	LONG lRef = InterlockedDecrement(&m_lRef);
	if (lRef == 0) {
		delete this;
	}
	return lRef;
}

STDMETHODIMP EventSink::QueryInterface(REFIID riid, void** ppv)
{
	if (riid == IID_IUnknown || riid == IID_IWbemObjectSink) {
		*ppv = (IWbemObjectSink*) this;
		AddRef();
		return WBEM_S_NO_ERROR;
	}
	else {
		return E_NOINTERFACE;
	}
}

STDMETHODIMP EventSink::Indicate(long lObjectCount, IWbemClassObject** apObjArray)
{
	HRESULT hr = S_OK;

	for (int i = 0; i < lObjectCount; i++) {
		int nInstanceType = 0;
		_variant_t cn;
		hr = apObjArray[i]->Get(_bstr_t(L"__Class"), 0, &cn, 0, 0);
		if (SUCCEEDED(hr)) {
			CString strClassName(cn.bstrVal);
			if (strClassName == TEXT("__InstanceDeletionEvent")) {
				nInstanceType = 1;
			}
			else if (strClassName == TEXT("__InstanceCreationEvent")) {
				nInstanceType = 2;
			}
		}
		VariantClear(&cn);

		if (nInstanceType != 0) {

			_variant_t vtProp;
			hr = apObjArray[i]->Get(_bstr_t(L"TargetInstance"), 0, &vtProp, 0, 0);
			if (SUCCEEDED(hr)) {
				IUnknown* str = vtProp;
				hr = str->QueryInterface(IID_IWbemClassObject, reinterpret_cast<void**>(&apObjArray[i]));
				if (SUCCEEDED(hr)) {
					_variant_t vtName;
					hr = apObjArray[i]->Get(_bstr_t(L"Name"), 0, &vtName, NULL, NULL);
					if (SUCCEEDED(hr)) {
						if (vtName.vt == VT_BSTR) {
							CString strProcName(vtName.bstrVal);
							_tprintf(TEXT("[%s] ProcessName : %s\n"), nInstanceType == 2 ? 
								TEXT("NEW") : TEXT("DEL"), strProcName.GetString());
						}
					}
					VariantClear(&vtName);
				}
			}
			VariantClear(&vtProp);
		}
		
		
	}

	return WBEM_S_NO_ERROR;
}

STDMETHODIMP EventSink::SetStatus(
	/* [in] */ LONG lFlags,
	/* [in] */ HRESULT hResult,
	/* [in] */ BSTR strParam,
	/* [in] */ IWbemClassObject __RPC_FAR *pObjParam
	)
{
	if (lFlags == WBEM_STATUS_COMPLETE) {
		printf("Call complete, hResult = 0x%X\n", hResult);
	}
	else if (lFlags == WBEM_STATUS_PROGRESS) {
		printf("Call in progress.\n");
	}

	return WBEM_S_NO_ERROR;
}
