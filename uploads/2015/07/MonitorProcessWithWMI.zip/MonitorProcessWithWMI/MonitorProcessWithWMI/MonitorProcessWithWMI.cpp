// MonitorProcessWithWMI.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "EventSink.h"

class CInitialize{
public:
	CInitialize() { CoInitializeEx(0, COINITBASE_MULTITHREADED); }
	~CInitialize() { CoUninitialize(); }
};

int _tmain(int argc, _TCHAR* argv[])
{
	HRESULT hr;

	CInitialize co_init;

	hr = CoInitializeSecurity(
		NULL,
		-1,				// COM negotiates service
		NULL,			// Authentication services
		NULL,			// Reserved
		RPC_C_AUTHN_LEVEL_DEFAULT,		// Default authentication
		RPC_C_IMP_LEVEL_IMPERSONATE,	// Default impersonation
		NULL,							// Authentication info
		EOAC_NONE,						// Additional capabilities
		NULL							// Reserved		
		);

	if (FAILED(hr)) {
		return 1;
	}

	CComPtr<IWbemLocator> loc;

	hr = CoCreateInstance(
		CLSID_WbemLocator,
		0,
		CLSCTX_INPROC_SERVER,
		IID_IWbemLocator,
		(LPVOID *)&loc
		);

	if (FAILED(hr)) {
		return 1;
	}

	CComPtr<IWbemServices> svc;

	hr = loc->ConnectServer(
		_bstr_t(L"ROOT\\CIMV2"),
		NULL,
		NULL,
		0,
		NULL,
		0,
		0,
		&svc
		);

	if (FAILED(hr)) {
		return 1;
	}

	hr = CoSetProxyBlanket(
		svc,				// indicates the proxy to set
		RPC_C_AUTHN_WINNT,
		RPC_C_AUTHZ_NONE,
		NULL,				// server principal name
		RPC_C_AUTHN_LEVEL_CALL,	//
		RPC_C_IMP_LEVEL_IMPERSONATE,
		NULL,				// client identity
		EOAC_NONE			// proxy capabilities
		);

	if (FAILED(hr)) {
		return 1;
	}

	CComPtr<IUnsecuredApartment> unsec_app;
	hr = CoCreateInstance(CLSID_UnsecuredApartment, NULL, CLSCTX_LOCAL_SERVER, IID_IUnsecuredApartment, (void**)&unsec_app);
	if (FAILED(hr)) {
		return 1;
	}


	CComPtr<IWbemObjectSink> event_sink(new EventSink);
	event_sink.p->AddRef();

	CComPtr<IUnknown> stub_unknown;
	unsec_app->CreateObjectStub(event_sink, &stub_unknown);

	CComPtr<IWbemObjectSink> stub_sink;
	stub_unknown->QueryInterface(IID_IWbemObjectSink, (void**)&stub_sink);

	hr = svc->ExecNotificationQueryAsync(
		_bstr_t("WQL"),
		_bstr_t("SELECT * "
		"FROM  __InstanceOperationEvent WITHIN 1 "
		"WHERE TargetInstance ISA 'Win32_Process'"),
		WBEM_FLAG_SEND_STATUS,
		NULL,
		stub_sink
		);

	if (FAILED(hr)) {
		return 1;
	}

	getchar();

	hr = svc->CancelAsyncCall(stub_sink);

	return 0;
}

