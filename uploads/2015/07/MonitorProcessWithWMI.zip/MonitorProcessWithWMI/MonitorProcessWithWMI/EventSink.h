#pragma once
class EventSink : public IWbemObjectSink
{
public:
	EventSink() { m_lRef = 0; }
	~EventSink() {}

	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();
	STDMETHOD(QueryInterface)(REFIID riid, void** ppv);
	STDMETHOD(Indicate)(LONG lObjectCount, IWbemClassObject __RPC_FAR *__RPC_FAR *apObjArray);
	STDMETHOD(SetStatus)(
		/* in */ LONG lFlags,
		/* in */ HRESULT hResult,
		/* in */ BSTR strParam,
		/* in */ IWbemClassObject __RPC_FAR *pObjParam);
private:
	LONG m_lRef;
};

