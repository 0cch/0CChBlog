#include "MinidumpGenerator.h"

namespace xbk
{
	/*=================== Config =====================*/

	string MinidumpDir = "";

	string ZipDir = "";

	string BugReporterPath = "";

	MINIDUMP_TYPE MdT = MiniDumpNormal; 

	/*=================== Config =====================*/

	LPTOP_LEVEL_EXCEPTION_FILTER MinidumpGenerator::m_previousFilter;


	void MinidumpGenerator::CallBugReportor(string &DumpPath)
	{
		ostringstream CommandLineSS;
		CHAR BaseName[MAX_PATH];
		PCHAR Pos;
		CHAR CommandLine[1024];
		STARTUPINFO si = {0};
		PROCESS_INFORMATION pi = {0};
		si.cb = sizeof(STARTUPINFO);

		if (BugReporterPath.empty()) {

			return;
		}

		if (!ZipDir.empty()) {

			CommandLineSS << "app " << "-o" << " " << "\"" << ZipDir << "\"" << " ";
		}

		CommandLineSS << "-d" << " " << "\"" << DumpPath << "\"" << " ";
		CommandLineSS << "-p" << " " << GetCurrentProcessId() << " ";

		
		GetModuleFileName(NULL, BaseName, MAX_PATH);
		Pos = strrchr(BaseName, '\\');
		Pos++;

		CommandLineSS << "-e" << " " << "\"" << Pos << "\"" << " ";

		strcpy_s(CommandLine, sizeof(CommandLine), CommandLineSS.str().c_str());

		CreateProcess(BugReporterPath.c_str(), 
			CommandLine, 
			NULL, 
			NULL, 
			FALSE, 
			0, 
			NULL, 
			NULL, 
			&si, 
			&pi);

		return;

	}

	string MinidumpGenerator::GetDumpName() 
	{
		CHAR buf[MAX_PATH];
		DWORD len = MAX_PATH;
		SYSTEMTIME Time;
		ostringstream DumpName;
		CHAR BaseName[MAX_PATH];

		GetModuleFileName(NULL, BaseName, MAX_PATH);

		if (MinidumpDir.empty()) {

			DumpName << BaseName << ".";

		}
		else {

			PCHAR Pos = strrchr(BaseName, '\\');
			DumpName << MinidumpDir << Pos << ".";
		}

		DumpName << GetCurrentProcessId() << ".";

		if (GetComputerNameA(buf, &len)) {
			DumpName << buf;
			DumpName << ".";
		}

		if (GetUserName(buf, &len)) {

			DumpName << buf;
			DumpName << ".";
		}

		GetLocalTime(&Time);
		DumpName.fill('0');
		DumpName << Time.wYear
			<< setw(2) << Time.wMonth
			<< setw(2) << Time.wDay
			<< '-'
			<< setw(2) << Time.wHour
			<< setw(2) << Time.wMinute
			<< setw(2) << Time.wSecond;

		DumpName << ".dmp";

		return DumpName.str();

	}

	LONG WINAPI MinidumpGenerator::MGUnhandledExceptionFilter(PEXCEPTION_POINTERS lpExceptionInfo)
	{
		MINIDUMP_EXCEPTION_INFORMATION mdei = {0};
		BOOL Ret;
		HANDLE File;
		string DumpFileName = MinidumpGenerator::GetDumpName();

		File = CreateFile(DumpFileName.c_str(),
			GENERIC_READ | GENERIC_WRITE,
			0, 
			NULL, 
			CREATE_ALWAYS, 
			FILE_ATTRIBUTE_NORMAL, 
			NULL);
		if (File == INVALID_HANDLE_VALUE) {

			return FALSE;
		}

		mdei.ThreadId = GetCurrentThreadId();
		mdei.ExceptionPointers = lpExceptionInfo;
		mdei.ClientPointers = FALSE;

		Ret = MiniDumpWriteDump(GetCurrentProcess(), 
			GetCurrentProcessId(),
			File, 
			MdT, 
			(lpExceptionInfo != 0) ? &mdei : 0, 
			0, 
			0);

		CloseHandle(File);

		CallBugReportor(DumpFileName);

		return (LONG)Ret;
	}


	MinidumpGenerator::MinidumpGenerator()
	{
		MinidumpGenerator::m_previousFilter = 
			SetUnhandledExceptionFilter(MinidumpGenerator::MGUnhandledExceptionFilter);

	}

	MinidumpGenerator::~MinidumpGenerator()
	{
		SetUnhandledExceptionFilter(MinidumpGenerator::m_previousFilter);
	}

	BOOL MinidumpGenerator::GetConfigFromReg(HKEY hKey, LPCSTR lpSubKey)
	{
		HKEY Key;
		LONG Ret;
		BYTE Buffer[1024];
		ULONG Length;

		Ret = RegOpenKeyEx(hKey, lpSubKey, 0, KEY_QUERY_VALUE, &Key);
		if (Ret != ERROR_SUCCESS) {

			return FALSE;
		}

		Length = sizeof(Buffer);

		Ret = RegQueryValueEx(Key, "MinidumpDir", 0, NULL, Buffer, &Length);
		if (Ret != ERROR_SUCCESS) {

			RegCloseKey(Key);
			return FALSE;
		}

		MinidumpDir = (CHAR *)Buffer;
		
		Length = sizeof(Buffer);

		Ret = RegQueryValueEx(Key, "ZipDir", 0, NULL, Buffer, &Length);
		if (Ret != ERROR_SUCCESS) {

			RegCloseKey(Key);
			return FALSE;
		}

		ZipDir = (CHAR *)Buffer;

		Length = sizeof(Buffer);

		Ret = RegQueryValueEx(Key, "BugReporterPath", 0, NULL, Buffer, &Length);
		if (Ret != ERROR_SUCCESS) {

			RegCloseKey(Key);
			return FALSE;
		}

		BugReporterPath = (CHAR *)Buffer;

		RegCloseKey(Key);

		return TRUE;
	}

}