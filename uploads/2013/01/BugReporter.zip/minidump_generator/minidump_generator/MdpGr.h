#ifndef __MDP_GR_H__
#define __MDP_GR_H__

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _EXPORT_DLL
	__declspec(dllexport) BOOL __stdcall InitBugReport(HKEY hKey, LPCSTR lpSubKey);
#else
	__declspec(dllimport) BOOL __stdcall InitBugReport(HKEY hKey, LPCSTR lpSubKey);
#endif

#ifdef __cplusplus
	};
#endif


#endif