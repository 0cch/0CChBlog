#ifndef __MINIDUMP_GENERATOR_H__
#define __MINIDUMP_GENERATOR_H__

#include <iomanip>
#include <string>
#include <sstream>
#include <windows.h>
#include <DbgHelp.h>

#include <iostream>


#pragma comment(lib, "DbgHelp.lib")

using namespace std;

namespace xbk {


	class MinidumpGenerator
	{
	public:
		MinidumpGenerator();
		~MinidumpGenerator();

		static LONG WINAPI MGUnhandledExceptionFilter(
			PEXCEPTION_POINTERS lpExceptionInfo );

		static LPTOP_LEVEL_EXCEPTION_FILTER m_previousFilter;

		static string GetDumpName();

		static void CallBugReportor(string &DumpPath);

		static BOOL GetConfigFromReg(HKEY hKey, LPCSTR lpSubKey);

		static string m_DumpDir;
	};
}



#endif