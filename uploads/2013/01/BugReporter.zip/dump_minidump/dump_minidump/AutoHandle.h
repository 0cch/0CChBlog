#ifndef __SMART_HANDLE_H__
#define __SMART_HANDLE_H__

#include <windows.h>


class AutoGeneralHandle
{
public:
	AutoGeneralHandle(HANDLE Value) 
	{
		m_Value = Value;
	}
	~AutoGeneralHandle() 
	{
		CloseHandle(m_Value);
	}

	AutoGeneralHandle& operator = (HANDLE Value)
	{
		this->m_Value = Value;
		return *this;
	}

	operator HANDLE()
	{
		return this->m_Value;
	}

private:
	HANDLE m_Value;
};


class AutoModuleHandle
{
public:
	AutoModuleHandle(HMODULE Value) 
	{
		m_Value = Value;
	}
	~AutoModuleHandle() 
	{
		FreeLibrary(m_Value);
	}

	AutoModuleHandle& operator = (HMODULE Value)
	{
		this->m_Value = Value;
		return *this;
	}

	operator HMODULE()
	{
		return this->m_Value;
	}


private:
	HMODULE m_Value;
};


class AutoKeyHandle
{
public:
	AutoKeyHandle(HKEY Value) 
	{
		m_Value = Value;
	}
	~AutoKeyHandle() 
	{
		RegCloseKey(m_Value);
	}

	AutoKeyHandle& operator = (HKEY Value)
	{
		this->m_Value = Value;
		return *this;
	}

	operator HKEY()
	{
		return this->m_Value;
	}

private:
	HKEY m_Value;
};





#endif