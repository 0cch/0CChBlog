#include "Minidump.h"
#include "BeaEngine.h"
#include "bea-reloc.h"

string MinidumpStream::WideToMutli( wstring Wide )
{
	int charcount = WideCharToMultiByte(CP_ACP, 0, Wide.c_str(), -1,
		NULL, 0, NULL, NULL);
	if (charcount == 0) {
		return string();
	}

	// convert
	char *buf = new char[charcount];
	WideCharToMultiByte(CP_UTF8, 0, Wide.c_str(), -1, buf, charcount,
		NULL, NULL);

	string result(buf);
	delete[] buf;
	return result;
}

BOOL MinidumpStream::DumpStream(ULONG StreamType)
{
	PMINIDUMP_DIRECTORY DumpDir;
	ULONG InfoSize;

	return MiniDumpReadDumpStream(m_DumpBuffer, StreamType, &DumpDir, &m_TargetStream, &InfoSize);
}

string MinidumpSystemStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_SYSTEM_INFO Info;

	InfoStr << "SYSTEM INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO SYSTEM INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_SYSTEM_INFO)m_TargetStream;

	InfoStr << "ProcessorArchitecture : ";
	switch (Info->ProcessorArchitecture) {

		case PROCESSOR_ARCHITECTURE_INTEL:
			InfoStr << "x86";
			break;
		case PROCESSOR_ARCHITECTURE_IA64:
			InfoStr << "Intel Itanium Processor Family (IPF)";
			break;
		case PROCESSOR_ARCHITECTURE_AMD64:
			InfoStr << "x64 (AMD or Intel)";
			break;
		default:
			InfoStr << "Unknown processor";
			break;
	}

	InfoStr << endl;

	InfoStr << "Number Of Processors : " << (ULONG)Info->NumberOfProcessors << endl;

	InfoStr << "OS Version : " << Info->MajorVersion << "." << Info->MinorVersion << endl;

	InfoStr << "BuildNumber : " << Info->BuildNumber << endl;

	InfoStr << "CSDVersion : ";
	InfoStr << WideToMutli(((PMINIDUMP_STRING)((PUCHAR)m_DumpBuffer + Info->CSDVersionRva))->Buffer);
	InfoStr << endl;

	InfoStr << "Platform : ";
	switch (Info->PlatformId) {

		case VER_PLATFORM_WIN32s:
			InfoStr << "Win32s";
			break;
		case VER_PLATFORM_WIN32_WINDOWS:
			InfoStr << "Windows Me, Windows 98, or Windows 95";
			break;
		case VER_PLATFORM_WIN32_NT:
			InfoStr << "Windows Server 2003, Windows XP, or Windows 2000";
			break;
		default:
			InfoStr << "Unknown";
			break;
	}

	InfoStr << endl << endl;

	return InfoStr.str();
}


string MinidumpExceptionStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_EXCEPTION_STREAM Info;

	ULONG i;
	PCONTEXT Cxt;

	InfoStr << "EXCEPTION INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO EXCEPTION INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_EXCEPTION_STREAM)m_TargetStream;

	InfoStr << "Thread id : " << Info->ThreadId << endl;

	InfoStr << "ExceptionCode : " << setbase(16) << setfill('0') 
		<< setw(8) << Info->ExceptionRecord.ExceptionCode << endl;

	InfoStr << "ExceptionFlags : " << setbase(16) << setfill('0') 
		<< setw(8) << Info->ExceptionRecord.ExceptionFlags << endl;

	InfoStr <<  "ExceptionRecord : " << setbase(16) << setfill('0') 
		<< setw(16) << Info->ExceptionRecord.ExceptionRecord << endl;

	InfoStr << "ExceptionAddress : " << setbase(16) << setfill('0') 
		<< setw(16) << Info->ExceptionRecord.ExceptionAddress << endl;


	for (i = 0; i < Info->ExceptionRecord.NumberParameters; i++) {

		InfoStr << "ExceptionInformation" << i << " = " << setbase(16) << setfill('0') 
			<< setw(16) << Info->ExceptionRecord.ExceptionInformation[i] << endl;

	}

	Cxt = (PCONTEXT)(Info->ThreadContext.Rva + (PUCHAR)m_DumpBuffer);
	InfoStr << "Thread Context : " << endl;
	InfoStr << setbase(16) << setfill('0');

	InfoStr << "EAX = "  << setw(8) << Cxt->Eax << "  " << "ECX = " << setw(8) << Cxt->Ecx << "  "
		<< "EDX = " << setw(8) << Cxt->Edx << "  " << "EBX = " << setw(8) << Cxt->Ebx << endl;

	InfoStr << "ESP = " << setw(8) << Cxt->Esp << "  " << "EBP = " << setw(8) << Cxt->Ebp << "  "
		<< "ESI = " << setw(8) << Cxt->Esi << "  " << "EDI = " << setw(8) << Cxt->Edi << endl;

	InfoStr << "EFLAGS = " << setw(8) << Cxt->EFlags << endl;

	InfoStr << endl;

	return InfoStr.str();
}

BOOL MinidumpExceptionStream::ParseStream( ULONG64 *Addr )
{
	PMINIDUMP_EXCEPTION_STREAM Info;

	if (!DumpStream()) {

		return FALSE;
	}

	Info = (PMINIDUMP_EXCEPTION_STREAM)m_TargetStream;


	*Addr = Info->ExceptionRecord.ExceptionAddress;

	return TRUE;
}


string MinidumpMemoryListStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_MEMORY_LIST Info;
	ULONG i;

	InfoStr << "MEMORY INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO MEMORY INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_MEMORY_LIST)m_TargetStream;

	InfoStr << setw(16) << setfill(' ') << "Start Address" << "    ";
	InfoStr << setw(16) << setfill(' ') << "Data Size" << setbase(16) << endl;

	for (i = 0; i < Info->NumberOfMemoryRanges; i++) {

		InfoStr << setw(16) << setfill('0') << Info->MemoryRanges[i].StartOfMemoryRange << "    ";
		InfoStr << setw(16) << setfill('0') << Info->MemoryRanges[i].Memory.DataSize << endl;
	}

	InfoStr << endl;

	return InfoStr.str();
}

BOOL MinidumpMemoryListStream::ParseStream( vector<MEM_LIST> &MemList )
{
	PMINIDUMP_MEMORY_LIST Info;
	ULONG i;
	MEM_LIST MemItem;

	if (!DumpStream()) {

		return FALSE;
	}

	Info = (PMINIDUMP_MEMORY_LIST)m_TargetStream;


	for (i = 0; i < Info->NumberOfMemoryRanges; i++) {

		MemItem.StartOfMemoryRange = Info->MemoryRanges[i].StartOfMemoryRange;
		MemItem.DataSize = Info->MemoryRanges[i].Memory.DataSize;
		MemItem.Rva = Info->MemoryRanges[i].Memory.Rva;

		MemList.push_back(MemItem);
	}


	return TRUE;
}
string MinidumpMemory64ListStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_MEMORY64_LIST Info;
	ULONG i;

	InfoStr << "MEMORY64 INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO MEMORY64 INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_MEMORY64_LIST)m_TargetStream;

	InfoStr << setw(16) << setfill(' ') << "Start Address" << "    ";
	InfoStr << setw(16) << setfill(' ') << "Data Size" << setbase(16) << endl;

	for (i = 0; i < Info->NumberOfMemoryRanges; i++) {

		InfoStr << setw(16) << setfill('0') << Info->MemoryRanges[i].StartOfMemoryRange << "    ";
		InfoStr << setw(16) << setfill('0') << Info->MemoryRanges[i].DataSize << endl;
	}

	InfoStr << endl;

	return InfoStr.str();
}

string MinidumpModuleListStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_MODULE_LIST Info;
	ULONG i;

	InfoStr << "MODULE INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO MODULE INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_MODULE_LIST)m_TargetStream;

	InfoStr << "Base" << "  "  << "Size" << "  " << "Name" << "  ";
	InfoStr << "FileVersion" << "  " << "ProductVersion" << endl;

	InfoStr << setfill('0') << setbase(16);


	for (i = 0; i < Info->NumberOfModules; i++) {

		InfoStr << setw(16) << Info->Modules[i].BaseOfImage << "  ";
		InfoStr << setw(8) << Info->Modules[i].SizeOfImage << "  ";
		InfoStr << WideToMutli(((PMINIDUMP_STRING)((PUCHAR)m_DumpBuffer 
			+ Info->Modules[i].ModuleNameRva))->Buffer) << "  ";
		InfoStr << MAKEULONGLONG(Info->Modules[i].VersionInfo.dwFileVersionLS, 
			Info->Modules[i].VersionInfo.dwFileVersionMS) << "  ";
		InfoStr << MAKEULONGLONG(Info->Modules[i].VersionInfo.dwProductVersionLS, 
			Info->Modules[i].VersionInfo.dwProductVersionMS) << "  " << endl;
	}

	InfoStr << endl;

	return InfoStr.str();

}

std::string MinidumpHandleDataStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_HANDLE_DATA_STREAM Info;
	PMINIDUMP_HANDLE_DESCRIPTOR HandleInfo;
	ULONG i;
	ULONG Count;
	ULONG Size;

	InfoStr << "HANDLE INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO HANDLE INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_HANDLE_DATA_STREAM)m_TargetStream;
	Count = Info->NumberOfDescriptors;
	Size = Info->SizeOfDescriptor;

	HandleInfo = (PMINIDUMP_HANDLE_DESCRIPTOR)((PUCHAR)Info + Info->SizeOfHeader);

	InfoStr << "Handle" << "  " << "Attributes" << "  " << "GrantedAccess"
		<< "TypeName" << "  " << "ObjectName" << endl;

	InfoStr << setfill('0') << setbase(16);

	for (i = 0; i < Count; i++) {

		InfoStr << setw(16) << HandleInfo->Handle << "  ";
		InfoStr << setw(8) << HandleInfo->Attributes << "  ";
		InfoStr << setw(8) << HandleInfo->GrantedAccess << "  ";
		if (HandleInfo->TypeNameRva != 0) {

			InfoStr << WideToMutli(((PMINIDUMP_STRING)((PUCHAR)m_DumpBuffer 
				+ HandleInfo->TypeNameRva))->Buffer) << "  ";
		}

		if (HandleInfo->ObjectNameRva != 0) {

			InfoStr << WideToMutli(((PMINIDUMP_STRING)((PUCHAR)m_DumpBuffer 
				+ HandleInfo->ObjectNameRva))->Buffer) << "  ";
		}

		InfoStr << endl;

		HandleInfo = (PMINIDUMP_HANDLE_DESCRIPTOR)((PUCHAR)HandleInfo + Size);
	}

	InfoStr << endl;

	return InfoStr.str();
}

string MinidumpThreadListStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_THREAD_LIST Info;
	ULONG i, j;
	ULONG Count;
	ULONG64 StartOfMemoryRange;
	ULONG64 DataSize;
	PULONG StartAtDump;
	PCONTEXT Cxt;

	InfoStr << "THREAD INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO THREAD INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_THREAD_LIST)m_TargetStream;

	for (i = 0; i < Info->NumberOfThreads; i++) {

		InfoStr << setfill('0') << setbase(10);

		InfoStr << "TID : " << Info->Threads[i].ThreadId << endl;
		InfoStr << "SuspendCount : " << Info->Threads[i].SuspendCount << endl;
		InfoStr << "Stack : " << endl;

		StartOfMemoryRange = Info->Threads[i].Stack.StartOfMemoryRange;
		StartAtDump = (PULONG)((ULONG)Info->Threads[i].Stack.Memory.Rva + (PUCHAR)m_DumpBuffer);
		DataSize = Info->Threads[i].Stack.Memory.DataSize;
		Count = (ULONG)DataSize / sizeof(PULONG);
		Count = Count > 15 ? 15 : Count;

		for (j = 0; j < Count; j++) {

			InfoStr << setfill('0') << setbase(16);
			InfoStr << setw(16) << StartOfMemoryRange << "  ";
			InfoStr << setw(8) << StartAtDump[j] << endl;

			StartOfMemoryRange += sizeof(PVOID);
		}

		Cxt = (PCONTEXT)(Info->Threads[i].ThreadContext.Rva + (PUCHAR)m_DumpBuffer);

		InfoStr << "EAX = "  << setw(8) << Cxt->Eax << "  " << "ECX = " << setw(8) << Cxt->Ecx << "  "
			<< "EDX = " << setw(8) << Cxt->Edx << "  " << "EBX = " << setw(8) << Cxt->Ebx << endl;

		InfoStr << "ESP = " << setw(8) << Cxt->Esp << "  " << "EBP = " << setw(8) << Cxt->Ebp << "  "
			<< "ESI = " << setw(8) << Cxt->Esi << "  " << "EDI = " << setw(8) << Cxt->Edi << endl;

		InfoStr << "EFLAGS = " << setw(8) << Cxt->EFlags << endl;

		InfoStr << endl;
	}

	InfoStr << endl;

	return InfoStr.str();
}

std::string MinidumpUnloadedModuleListStream::ParseStream()
{
	ostringstream InfoStr;
	PMINIDUMP_UNLOADED_MODULE_LIST Info;
	PMINIDUMP_UNLOADED_MODULE UMInfo;
	ULONG i;
	ULONG Count;
	ULONG Size;

	InfoStr << "UNLOADE MODULE INFORMATIONS\r\n---------------\r\n";

	if (!DumpStream()) {

		InfoStr << "NO UNLOADE MODULE INFORMATIONS!" << endl << endl;

		return InfoStr.str();
	}

	Info = (PMINIDUMP_UNLOADED_MODULE_LIST)m_TargetStream;
	Size = Info->SizeOfEntry;
	Count = Info->NumberOfEntries;
	UMInfo = (PMINIDUMP_UNLOADED_MODULE)((PUCHAR)Info + Info->SizeOfHeader);

	InfoStr << "Base" << "  "  << "Size" << "  " << "Name" << endl;

	for (i = 0; i < Count; i++) {

		InfoStr << setw(16) << UMInfo->BaseOfImage << "  ";
		InfoStr << setw(8) << UMInfo->SizeOfImage << "  ";
		InfoStr << WideToMutli(((PMINIDUMP_STRING)((PUCHAR)m_DumpBuffer 
			+ UMInfo->ModuleNameRva))->Buffer) << endl;

		UMInfo = (PMINIDUMP_UNLOADED_MODULE)((PUCHAR)UMInfo + Size);
		
	}

	InfoStr << endl;

	return InfoStr.str();
}

BOOL MinidumpParseFactory::InitMinidump( LPCSTR MinidumpPathName )
{
	AutoGeneralHandle FileHandle = CreateFile(MinidumpPathName, 
		GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, 
		0, 0);

	if ((HANDLE)FileHandle == INVALID_HANDLE_VALUE) {

		return FALSE;
	}

	AutoGeneralHandle MapHandle = CreateFileMapping(FileHandle, 
		NULL, PAGE_READWRITE, 0, 0, NULL);

	if ((HANDLE)MapHandle == NULL) {

		return FALSE;
	}

	PVOID DumpBuffer = MapViewOfFile(MapHandle,  
		FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0);

	if (DumpBuffer == NULL) {

		return FALSE;
	}

	m_DumpBuffer = DumpBuffer;


	return TRUE;
}

VOID MinidumpParseFactory::RegisterMinidumpParse( ULONG StreamType )
{
	switch (StreamType) {
		case MD_THREAD_STREAM:
			if (m_MinidumpStreamSetMap[MD_THREAD_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpThreadListStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_THREAD_STREAM] = 1;
			}
			break;
		case MD_MODULE_STREAM:
			if (m_MinidumpStreamSetMap[MD_MODULE_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpModuleListStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_MODULE_STREAM] = 1;
			}
			break;
		case MD_MEMORY_STREAM:
			if (m_MinidumpStreamSetMap[MD_MEMORY_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpMemoryListStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_MEMORY_STREAM] = 1;
			}
			break;
		case MD_EXCEPTION_STREAM:
			if (m_MinidumpStreamSetMap[MD_EXCEPTION_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpExceptionStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_EXCEPTION_STREAM] = 1;
			}
			break;
		case MD_SYSTEM_STREAM:
			if (m_MinidumpStreamSetMap[MD_SYSTEM_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpSystemStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_SYSTEM_STREAM] = 1;
			}
			break;
		case MD_MEMORY64_STREAM:
			if (m_MinidumpStreamSetMap[MD_MEMORY64_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpMemory64ListStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_MEMORY64_STREAM] = 1;
			}
			break;
		case MD_HANDLE_STREAM:
			if (m_MinidumpStreamSetMap[MD_HANDLE_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpHandleDataStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_HANDLE_STREAM] = 1;
			}
			break;
		case MD_UNLOADEDMOUULE_STREAM:
			if (m_MinidumpStreamSetMap[MD_UNLOADEDMOUULE_STREAM] == 0) {
				m_MinidumpStreamSet.push_back(new MinidumpUnloadedModuleListStream(m_DumpBuffer));
				m_MinidumpStreamSetMap[MD_UNLOADEDMOUULE_STREAM] = 1;
			}
			break;
		default:
			break;
	}
}

string MinidumpParseFactory::DumpMinidump()
{
	string OutStr;
	vector<MinidumpStream *>::iterator it;

	for (it = m_MinidumpStreamSet.begin(); it != m_MinidumpStreamSet.end(); it++) {

		OutStr += (*it)->ParseStream();
	}

	return OutStr;
}

BOOL MinidumpParseFactory::DisasmCrashIP( string &code )
{
	MinidumpMemoryListStream MemListStream(m_DumpBuffer);
	MinidumpExceptionStream ExceptStream(m_DumpBuffer);

	vector<MinidumpMemoryListStream::MEM_LIST> MemList;
	vector<MinidumpMemoryListStream::MEM_LIST>::iterator it;

	ULONG64 CrashIP;

	BOOL Ret = FALSE;
	ULONG i;
	INT Len;
	code = "Crash IP Disasm : \r\n";

	if (!MemListStream.ParseStream(MemList)) {
		return Ret;
	}

	if (!ExceptStream.ParseStream(&CrashIP)) {

		return Ret;
	}

	for (it = MemList.begin(); it != MemList.end(); it++) {

		if (it->StartOfMemoryRange <= CrashIP && 
			(it->StartOfMemoryRange + it->DataSize) > CrashIP) {

			Ret = TRUE;
			break;
		}
	}

	if (!Ret) {

		return Ret;
	}

	DISASM MyDisasm;
	ZeroMemory(&MyDisasm, sizeof(DISASM));

	MyDisasm.EIP = (UIntPtr)(CrashIP - it->StartOfMemoryRange + ((ULONG)m_DumpBuffer + it->Rva));

	for (i = 0; i < 1; i++) {

		Len = _Disasm(&MyDisasm);
		if (Len == UNKNOWN_OPCODE) {
			break;
		}

		MyDisasm.EIP += (UIntPtr)Len;
		code += MyDisasm.CompleteInstr;
		code += "\r\n";
	}

	return Ret;
}