// dump_minidump.cpp : Defines the entry point for the console application.
//
#ifdef _DEBUG

#include <cstdio>
#include <string>
#include <iostream>
#include <windows.h>
#include <DbgHelp.h>
#include "AutoHandle.h"
#include "Minidump.h"




using namespace std;

VOID PrintInfo(PVOID DumpBuffer)
{
	MinidumpSystemStream SysStream(DumpBuffer);
	MinidumpExceptionStream ExcStream(DumpBuffer);
	MinidumpMemoryListStream MemStream(DumpBuffer);
	MinidumpMemory64ListStream Mem64Stream(DumpBuffer);
	MinidumpModuleListStream ModStream(DumpBuffer);
	MinidumpHandleDataStream HanStream(DumpBuffer);
	MinidumpThreadListStream ThlStream(DumpBuffer);
	MinidumpUnloadedModuleListStream UMlStream(DumpBuffer);
	MinidumpStream *Stream = &SysStream;


	string Info = Stream->ParseStream();
	cout << Info;

	Stream = &ExcStream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &MemStream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &Mem64Stream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &ModStream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &HanStream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &ThlStream;
	Info = Stream->ParseStream();
	cout << Info;

	Stream = &UMlStream;
	Info = Stream->ParseStream();
	cout << Info;
}


int main(int argc, CHAR* argv[])
{
	MinidumpParseFactory Factory;

	Factory.InitMinidump("minidump.dmp");
	Factory.RegisterMinidumpParse(MD_THREAD_STREAM);
	Factory.RegisterMinidumpParse(MD_MODULE_STREAM);

	string ostr = Factory.DumpMinidump();

	cout << ostr;

// 	AutoGeneralHandle FileHandle = CreateFile("minidump.dmp", 
// 		GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, 
// 		0, 0);
// 
// 	AutoGeneralHandle MapHandle = CreateFileMapping(FileHandle, 
// 		NULL, PAGE_READWRITE, 0, 0, NULL);
// 
// 	PVOID DumpBuffer = MapViewOfFile(MapHandle,  
// 		FILE_MAP_WRITE | FILE_MAP_READ, 0, 0, 0);
// 
// 	PrintInfo(DumpBuffer);
// 
// 	UnmapViewOfFile(DumpBuffer);

	return 0;
}

#endif