#ifndef __MINIDUMP_H__
#define __MINIDUMP_H__

#include <vector>
#include <string>
#include <iomanip>
#include <sstream>
#include <windows.h>
#include <DbgHelp.h>
#include "AutoHandle.h"

#pragma comment(lib, "dbghelp.lib")

using namespace std;

#define endl "\r\n"

#define MAKEULONGLONG(a, b)      ((ULONGLONG)(((ULONG)(((ULONGLONG)(a)) & 0xffffffff)) | \
	((ULONGLONG)((ULONG)(((ULONGLONG)(b)) & 0xffffffff))) << 32))

enum {

	MD_THREAD_STREAM = 0,
	MD_MODULE_STREAM,
	MD_MEMORY_STREAM,
	MD_EXCEPTION_STREAM,
	MD_SYSTEM_STREAM,
	MD_MEMORY64_STREAM,
	MD_HANDLE_STREAM,
	MD_UNLOADEDMOUULE_STREAM,
	MD_STREAM_COUNT
};




class MinidumpStream {

public:
	MinidumpStream(PVOID DumpBuffer) : 
	  m_TargetStream(NULL), m_DumpBuffer(DumpBuffer) {}

	~MinidumpStream() {}

	virtual string ParseStream() {return FALSE;}

static string WideToMutli(wstring Wide);

protected:
	BOOL DumpStream(ULONG StreamType);

	PVOID m_TargetStream;
	PVOID m_DumpBuffer;
	
};

class MinidumpSystemStream : public MinidumpStream {

public:
	MinidumpSystemStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpSystemStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(SystemInfoStream);
	}
};


class MinidumpExceptionStream : public MinidumpStream {

public:
	MinidumpExceptionStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpExceptionStream() {}

	virtual string ParseStream();
	BOOL ParseStream(ULONG64 *Addr);

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(ExceptionStream);
	}
};

class MinidumpMemoryListStream : public MinidumpStream {

public:
	MinidumpMemoryListStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpMemoryListStream() {}

	virtual string ParseStream();

typedef struct _MEM_LIST {
	ULONG64 StartOfMemoryRange;
	ULONG32 DataSize;
	RVA Rva;
} MEM_LIST, *PMEM_LIST;
	BOOL ParseStream(vector<MEM_LIST> &MemList);

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(MemoryListStream);
	}
};

class MinidumpMemory64ListStream : public MinidumpStream {

public:
	MinidumpMemory64ListStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpMemory64ListStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(Memory64ListStream);
	}
};


class MinidumpModuleListStream : public MinidumpStream {

public:
	MinidumpModuleListStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpModuleListStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(ModuleListStream);
	}
};

class MinidumpHandleDataStream : public MinidumpStream {

public:
	MinidumpHandleDataStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpHandleDataStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(HandleDataStream);
	}
};

class MinidumpThreadListStream : public MinidumpStream {

public:
	MinidumpThreadListStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpThreadListStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(ThreadListStream);
	}
};

class MinidumpUnloadedModuleListStream : public MinidumpStream {

public:
	MinidumpUnloadedModuleListStream(PVOID DumpBuffer) : MinidumpStream(DumpBuffer) {}
	~MinidumpUnloadedModuleListStream() {}

	virtual string ParseStream();

protected:
	BOOL DumpStream()
	{
		return MinidumpStream::DumpStream(UnloadedModuleListStream);
	}
};


class MinidumpParseFactory {

public:
	MinidumpParseFactory()  : m_DumpBuffer(NULL) 
	{
		ZeroMemory(&m_MinidumpStreamSetMap, sizeof(m_MinidumpStreamSetMap));
	}
	~MinidumpParseFactory() 
	{
		UnmapViewOfFile(m_DumpBuffer);
	}


	BOOL InitMinidump(LPCSTR MinidumpPathName);
	VOID RegisterMinidumpParse(ULONG StreamType);
	string DumpMinidump();
	BOOL DisasmCrashIP(string &code);

private:

	UCHAR m_MinidumpStreamSetMap[MD_STREAM_COUNT];
	PVOID m_DumpBuffer;
	vector<MinidumpStream *> m_MinidumpStreamSet;
	
};



#endif