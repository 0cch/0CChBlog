// BugReporter.cpp : ����Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "BugReporter.h"
#include <string>
#include <fstream>
#include <sstream>
#include "zip.h"
#include "Minidump.h"
#include "http_upload.h"

#pragma comment(lib, "dump_minidump.lib")

using namespace std;

string g_ReportStr;
string g_DumpPathStr;
string g_ExeStr;
string g_PidStr;
string g_ZipDir;

INT_PTR CALLBACK	BugReporterProc(HWND, UINT, WPARAM, LPARAM);

PCHAR*
CommandLineToArgvA(
				   PCHAR CmdLine,
				   int* _argc
				   )
{
	PCHAR* argv;
	PCHAR  _argv;
	ULONG   len;
	ULONG   argc;
	CHAR   a;
	ULONG   i, j;

	BOOLEAN  in_QM;
	BOOLEAN  in_TEXT;
	BOOLEAN  in_SPACE;

	len = strlen(CmdLine);
	i = ((len+2)/2)*sizeof(PVOID) + sizeof(PVOID);

	argv = (PCHAR*)GlobalAlloc(GMEM_FIXED,
		i + (len+2)*sizeof(CHAR));

	_argv = (PCHAR)(((PUCHAR)argv)+i);

	argc = 0;
	argv[argc] = _argv;
	in_QM = FALSE;
	in_TEXT = FALSE;
	in_SPACE = TRUE;
	i = 0;
	j = 0;

	while( a = CmdLine[i] ) {
		if(in_QM) {
			if(a == '\"') {
				in_QM = FALSE;
			} else {
				_argv[j] = a;
				j++;
			}
		} else {
			switch(a) {
				case '\"':
					in_QM = TRUE;
					in_TEXT = TRUE;
					if(in_SPACE) {
						argv[argc] = _argv+j;
						argc++;
					}
					in_SPACE = FALSE;
					break;
				case ' ':
				case '\t':
				case '\n':
				case '\r':
					if(in_TEXT) {
						_argv[j] = '\0';
						j++;
					}
					in_TEXT = FALSE;
					in_SPACE = TRUE;
					break;
				default:
					in_TEXT = TRUE;
					if(in_SPACE) {
						argv[argc] = _argv+j;
						argc++;
					}
					_argv[j] = a;
					j++;
					in_SPACE = FALSE;
					break;
			}
		}
		i++;
	}
	_argv[j] = '\0';
	argv[argc] = NULL;

	(*_argc) = argc;
	return argv;
}

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	MinidumpParseFactory *Factory = new MinidumpParseFactory;
	INT Argc, i;
	INT StartCount = 0; 

	PCHAR *Argv = CommandLineToArgvA(lpCmdLine, &Argc);

	for (i = 0; i < Argc; i++) {

		if (_stricmp(Argv[i], "-d") == 0) {

			//
			// Dump file path
			//
			g_DumpPathStr = Argv[i + 1];
			StartCount++;
		}
		else if (_stricmp(Argv[i], "-p") == 0) {

			//
			// Process id
			//
			g_PidStr = Argv[i + 1];
			StartCount++;
		}
		else if (_stricmp(Argv[i], "-e") == 0) {

			g_ExeStr = Argv[i + 1];
			StartCount++;
		}
		else if (_stricmp(Argv[i], "-o") == 0) {

			g_ZipDir = Argv[i + 1];
		}
	}

	GlobalFree(Argv);

	if (StartCount != 3) {

		delete Factory;
		return 1;
	}

	if (Factory->InitMinidump(g_DumpPathStr.c_str())) {

		Factory->RegisterMinidumpParse(MD_SYSTEM_STREAM);
		Factory->RegisterMinidumpParse(MD_EXCEPTION_STREAM);
		Factory->RegisterMinidumpParse(MD_MODULE_STREAM);
		g_ReportStr = Factory->DumpMinidump();

		string CrashIPStr;
		if (Factory->DisasmCrashIP(CrashIPStr)) {

			g_ReportStr += CrashIPStr;
		}


	}
	else {

		g_ReportStr = "Cannot get bug report";
	}
	
	delete Factory;

	return DialogBox(hInstance, MAKEINTRESOURCE(IDD_BUGREPORT), NULL, BugReporterProc);
}

wstring MultiToWide(const string &Multi) 
{
	if (Multi.length() == 0) {
		return wstring();
	}

	// compute the length of the buffer we'll need
	int charcount = MultiByteToWideChar(CP_ACP, 0, Multi.c_str(), -1, NULL, 0);

	if (charcount == 0) {
		return wstring();
	}

	// convert
	wchar_t* buf = new wchar_t[charcount];
	MultiByteToWideChar(CP_ACP, 0, Multi.c_str(), -1, buf, charcount);
	wstring result(buf);
	delete[] buf;
	return result;
}

string GetZipName(LPCSTR BaseName) 
{
	CHAR buf[MAX_PATH];
	DWORD len = MAX_PATH;
	SYSTEMTIME Time;
	ostringstream ZipName;

	ZipName << BaseName << ".";

	if (GetComputerNameA(buf, &len)) {
		ZipName << buf;
		ZipName << ".";
	}

	if (GetUserName(buf, &len)) {

		ZipName << buf;
		ZipName << ".";
	}

	GetLocalTime(&Time);
	ZipName.fill('0');
	ZipName << Time.wYear
		<< setw(2) << Time.wMonth
		<< setw(2) << Time.wDay
		<< '-'
		<< setw(2) << Time.wHour
		<< setw(2) << Time.wMinute
		<< setw(2) << Time.wSecond;

	ZipName << ".zip";

	return ZipName.str();
	
}

bool SendBugReport(const wstring &url, const wstring &upload_file)
{
	map<wstring, wstring> parameters;
	wstring response_body;
	int response_code;
	return HTTPUpload::SendRequest(url, 
		parameters, 
		upload_file, 
		L"upload_file_minidump", 
		NULL,
		&response_body, 
		&response_code);
}


// �����ڡ������Ϣ��������
INT_PTR CALLBACK BugReporterProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	string Title = g_ExeStr + " BugReport";
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		
		SetWindowText(hDlg, Title.c_str());
		SendMessage(GetDlgItem(hDlg, IDC_CHECK_SEND), BM_SETCHECK, TRUE, 0);
		SetDlgItemText(hDlg, IDC_EDIT_BUGREPORT, g_ReportStr.c_str());
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK)
		{
			if (SendMessage(GetDlgItem(hDlg, IDC_CHECK_SEND), BM_GETCHECK, 0, 0)) {

				ofstream LogFile;
				string LogStr = g_DumpPathStr;
				string ZipName;
				INT Pos = LogStr.rfind("dmp");
				LogStr.replace(Pos, 3, "log");
				LogFile.open(LogStr.c_str());
				if (LogFile.is_open()) {

					LogFile << g_ReportStr;
					LogFile.close();

					if (g_ZipDir.empty()) {

						ZipName = g_DumpPathStr.substr(0, g_DumpPathStr.rfind("\\") + 1);
					}
					else {

						ZipName = g_ZipDir;
						if (ZipName[ZipName.length() - 1] != '\\') {

							ZipName += "\\";
						}
					}
					
					ZipName += g_ExeStr;
					ZipName += ".";
					ZipName += g_PidStr;

					string ZipFullPath = GetZipName(ZipName.c_str());
					wstring ZipFullPathW = MultiToWide(ZipFullPath);
					HZIP Zip = CreateZip(ZipFullPath.c_str(), 0);
					if (Zip != NULL) {

						ZipAdd(Zip, LogStr.substr(LogStr.rfind("\\") + 1).c_str(), LogStr.c_str());
						ZipAdd(Zip, g_DumpPathStr.substr(g_DumpPathStr.rfind("\\") + 1).c_str(), 
							g_DumpPathStr.c_str());
						CloseZip(Zip);

						// SendBugReport(L"http://0cch.net", ZipFullPathW);
					}
					
				}
			}

			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		else if (LOWORD(wParam) == IDCANCEL) {

			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
